# SignalDesk (Android) v1.1
หน้าเว็บ SignalDesk เดิม (app/src/main/assets/web) แสดงผลใน WebView
และมีตัวตรวจสัญญาณเขียนด้วย Kotlin ทำงานเป็น Foreground Service

ระบบราคาล้วน 5 แบบ (ใช้ร่วมกับแจ้งเตือน Telegram ได้ทั้งหมด)
- Liquidity Sweep (เดิม)
- BOS + Retest, Order Block, Fair Value Gap, Asian Range Sweep (ใหม่)
กรอบเวลา 5m / 15m / 1H / 4H / 1D (Asian Range Sweep ใช้ได้เฉพาะ 5m, 15m, 1H)

ไฟล์ตรรกะ: web/engines.js (กราฟ+แบ็กเทสต์) และ Engine.kt (แจ้งเตือนเบื้องหลัง) ต้องตรงกัน
