/* ระบบราคาล้วน 4 แบบ: BOS+Retest, Order Block, FVG, Asian Range Sweep
 * ทุกตัวรับ (bars, atr, lastClosed, p) และคืน { state, sig, conds, lines }
 * sig[i] = { side, sl, level } เหมือน sweepEngine เดิม ใช้เฉพาะแท่งที่ปิดแล้ว ไม่มองอนาคต */
(function (root) {
  'use strict';
  const RETEST = 20;      // BOS: รอทดสอบระดับที่หักได้ไม่เกินกี่แท่ง
  const OB_BODY = 1.5;    // OB: ตัวแท่งพุ่งอย่างน้อยกี่เท่า ATR
  const OB_BACK = 10;     // OB: ย้อนหาแท่งสวนทางไม่เกินกี่แท่ง
  const OB_LIFE = 50;     // OB: โซนหมดอายุกี่แท่ง
  const FVG_MIN = 0.5;    // FVG: ช่องกว้างอย่างน้อยกี่เท่า ATR
  const FVG_LIFE = 50;    // FVG: ช่องหมดอายุกี่แท่ง
  const ASIA_END = 7;     // ชั่วโมง UTC (07:00 UTC = 14:00 เวลาไทย) กรอบเอเชีย = 00:00-07:00 UTC
  const LON_END = 12;     // ช่วงลอนดอนที่รอกวาด 07:00-12:00 UTC

  const GOLD = 'rgba(232,179,74,.8)';

  function pivots(bars, N) {
    const P = { sh: null, sl: null };
    const isPH = (j) => { for (let k = j - N; k <= j + N; k++) if (k !== j && (k < j ? bars[k].high >= bars[j].high : bars[k].high > bars[j].high)) return false; return true; };
    const isPL = (j) => { for (let k = j - N; k <= j + N; k++) if (k !== j && (k < j ? bars[k].low <= bars[j].low : bars[k].low < bars[j].low)) return false; return true; };
    P.step = (i) => {
      const j = i - N;
      if (j >= N) {
        if (isPH(j)) P.sh = { price: bars[j].high, idx: j, used: false };
        if (isPL(j)) P.sl = { price: bars[j].low, idx: j, used: false };
      }
    };
    return P;
  }

  const sgn = (side) => (side === 'buy' ? 1 : -1);

  // ---------------------------------------------------------------- BOS + Retest
  function bosEngine(bars, atr, lastClosed, p) {
    const N = Math.max(2, p.swing | 0), state = [], sig = [], P = pivots(bars, N);
    let struct = 0, pend = null;
    for (let i = 0; i <= lastClosed; i++) {
      const b = bars[i];
      P.step(i);
      const buf = (atr[i] || 0) * p.slBuf;
      let fired = false;
      if (pend) {
        if (pend.dir === 1) {
          pend.ext = Math.min(pend.ext, b.low);
          if (b.low <= pend.level && b.close > pend.level) { sig[i] = { side: 'buy', sl: pend.ext - buf, level: pend.level }; fired = true; pend = null; }
          else if (b.close < pend.inval || i - pend.start > RETEST) pend = null;
        } else {
          pend.ext = Math.max(pend.ext, b.high);
          if (b.high >= pend.level && b.close < pend.level) { sig[i] = { side: 'sell', sl: pend.ext + buf, level: pend.level }; fired = true; pend = null; }
          else if (b.close > pend.inval || i - pend.start > RETEST) pend = null;
        }
      }
      if (!pend && !fired) {
        const sh = P.sh, sl = P.sl;
        if (sh && !sh.used && b.close > sh.price) {
          sh.used = true; struct = 1;
          pend = { dir: 1, level: sh.price, inval: sl ? sl.price : b.low, ext: Infinity, start: i };
        } else if (sl && !sl.used && b.close < sl.price) {
          sl.used = true; struct = -1;
          pend = { dir: -1, level: sl.price, inval: sh ? sh.price : b.high, ext: -Infinity, start: i };
        }
      }
      state[i] = { struct, wd: pend ? pend.dir : 0, lvl: pend ? pend.level : null };
    }
    const conds = (i, side, fmt) => {
      const s = sgn(side), st = state[i] || {};
      const hit = sig[i] && sig[i].side === side;
      const lv = hit ? sig[i].level : st.wd === s ? st.lvl : null;
      return [
        { label: s > 0 ? 'ราคาปิดทะลุ Swing High (BOS ขาขึ้น)' : 'ราคาปิดทะลุ Swing Low (BOS ขาลง)', ok: st.struct === s },
        { label: 'มีระดับรอทดสอบ ' + (lv ? fmt(lv) : '—'), ok: !!lv },
        { label: s > 0 ? 'ย่อลงแตะระดับแล้วปิดกลับเหนือ' : 'เด้งขึ้นแตะระดับแล้วปิดกลับใต้', ok: !!hit },
      ];
    };
    const lines = pend ? [{ price: pend.level, title: 'RETEST', color: GOLD }] : [];
    return { state, sig, conds, lines };
  }

  // ---------------------------------------------------------------- Order Block
  function obEngine(bars, atr, lastClosed, p) {
    const N = Math.max(2, p.swing | 0), state = [], sig = [], P = pivots(bars, N);
    let struct = 0, zones = [];
    for (let i = 0; i <= lastClosed; i++) {
      const b = bars[i];
      P.step(i);
      if (P.sh && b.close > P.sh.price && struct !== 1) struct = 1;
      else if (P.sl && b.close < P.sl.price && struct !== -1) struct = -1;
      const buf = (atr[i] || 0) * p.slBuf;
      zones = zones.filter((z) => i - z.born <= OB_LIFE && !(z.dir === 1 ? b.close < z.bottom : b.close > z.top));
      let fired = false;
      for (const z of zones) {
        if (z.dir === 1 && b.low <= z.top && b.close > z.top) { sig[i] = { side: 'buy', sl: Math.min(z.bottom, b.low) - buf, level: z.top }; z.used = true; fired = true; break; }
        if (z.dir === -1 && b.high >= z.bottom && b.close < z.bottom) { sig[i] = { side: 'sell', sl: Math.max(z.top, b.high) + buf, level: z.bottom }; z.used = true; fired = true; break; }
      }
      if (fired) zones = zones.filter((z) => !z.used);
      const a = atr[i];
      if (a != null && Math.abs(b.close - b.open) >= OB_BODY * a) {
        const sh = P.sh, sl = P.sl;
        if (b.close > b.open && sh && !sh.used && b.close > sh.price) {
          sh.used = true;
          for (let k = i - 1; k >= Math.max(0, i - OB_BACK); k--) {
            if (bars[k].close < bars[k].open) { zones.push({ dir: 1, top: bars[k].high, bottom: bars[k].low, born: i, used: false }); break; }
          }
        } else if (b.close < b.open && sl && !sl.used && b.close < sl.price) {
          sl.used = true;
          for (let k = i - 1; k >= Math.max(0, i - OB_BACK); k--) {
            if (bars[k].close > bars[k].open) { zones.push({ dir: -1, top: bars[k].high, bottom: bars[k].low, born: i, used: false }); break; }
          }
        }
      }
      state[i] = { struct, nUp: zones.filter((z) => z.dir === 1).length, nDn: zones.filter((z) => z.dir === -1).length };
    }
    const conds = (i, side) => {
      const s = sgn(side), st = state[i] || {};
      const hit = sig[i] && sig[i].side === side;
      const n = s > 0 ? st.nUp : st.nDn;
      return [
        { label: s > 0 ? 'แท่งพุ่งขึ้นแรงทะลุ Swing High' : 'แท่งพุ่งลงแรงทะลุ Swing Low', ok: st.struct === s },
        { label: (s > 0 ? 'มีโซน Order Block ขาขึ้น ' : 'มีโซน Order Block ขาลง ') + (n || hit ? '' : '(ยังไม่มี)'), ok: !!(n || hit) },
        { label: s > 0 ? 'ราคาแตะโซนแล้วปิดกลับเหนือขอบบน' : 'ราคาแตะโซนแล้วปิดกลับใต้ขอบล่าง', ok: !!hit },
      ];
    };
    const lines = [];
    zones.slice(-3).forEach((z) => {
      lines.push({ price: z.top, title: z.dir === 1 ? 'OB↑' : 'OB↓', color: GOLD });
      lines.push({ price: z.bottom, title: '', color: GOLD });
    });
    return { state, sig, conds, lines };
  }

  // ---------------------------------------------------------------- Fair Value Gap
  function fvgEngine(bars, atr, lastClosed, p) {
    const N = Math.max(2, p.swing | 0), state = [], sig = [], P = pivots(bars, N);
    let struct = 0, zones = [];
    for (let i = 0; i <= lastClosed; i++) {
      const b = bars[i];
      P.step(i);
      if (P.sh && b.close > P.sh.price && struct !== 1) struct = 1;
      else if (P.sl && b.close < P.sl.price && struct !== -1) struct = -1;
      const buf = (atr[i] || 0) * p.slBuf;
      zones = zones.filter((z) => i - z.born <= FVG_LIFE && !(z.dir === 1 ? b.close < z.bottom : b.close > z.top));
      let fired = false;
      for (const z of zones) {
        const mid = (z.top + z.bottom) / 2;
        if (z.dir === 1 && b.low <= z.top && b.close > mid) { sig[i] = { side: 'buy', sl: Math.min(z.bottom, b.low) - buf, level: z.top }; z.used = true; fired = true; break; }
        if (z.dir === -1 && b.high >= z.bottom && b.close < mid) { sig[i] = { side: 'sell', sl: Math.max(z.top, b.high) + buf, level: z.bottom }; z.used = true; fired = true; break; }
      }
      if (fired) zones = zones.filter((z) => !z.used);
      const a = atr[i];
      if (a != null && i >= 2) {
        const gapUp = b.low - bars[i - 2].high, gapDn = bars[i - 2].low - b.high;
        if (gapUp >= FVG_MIN * a && struct === 1) zones.push({ dir: 1, top: b.low, bottom: bars[i - 2].high, born: i, used: false });
        else if (gapDn >= FVG_MIN * a && struct === -1) zones.push({ dir: -1, top: bars[i - 2].low, bottom: b.high, born: i, used: false });
      }
      state[i] = { struct, nUp: zones.filter((z) => z.dir === 1).length, nDn: zones.filter((z) => z.dir === -1).length };
    }
    const conds = (i, side) => {
      const s = sgn(side), st = state[i] || {};
      const hit = sig[i] && sig[i].side === side;
      const n = s > 0 ? st.nUp : st.nDn;
      return [
        { label: s > 0 ? 'โครงสร้างขาขึ้น' : 'โครงสร้างขาลง', ok: st.struct === s },
        { label: (s > 0 ? 'มีช่องว่างราคา (FVG) ขาขึ้น ' : 'มีช่องว่างราคา (FVG) ขาลง ') + (n || hit ? '' : '(ยังไม่มี)'), ok: !!(n || hit) },
        { label: s > 0 ? 'ราคาย่อลงแตะช่องแล้วปิดเหนือกึ่งกลาง' : 'ราคาเด้งขึ้นแตะช่องแล้วปิดใต้กึ่งกลาง', ok: !!hit },
      ];
    };
    const lines = [];
    zones.slice(-3).forEach((z) => {
      lines.push({ price: z.top, title: z.dir === 1 ? 'FVG↑' : 'FVG↓', color: GOLD });
      lines.push({ price: z.bottom, title: '', color: GOLD });
    });
    return { state, sig, conds, lines };
  }

  // ---------------------------------------------------------------- Asian Range Sweep
  function asiaEngine(bars, atr, lastClosed, p) {
    const dur = p.dur || 3600, usable = dur <= 3600, state = [], sig = [];
    const expected = Math.floor((ASIA_END * 3600) / dur);
    let day = null, hi = -Infinity, lo = Infinity, cnt = 0, rng = null, doneBuy = false, doneSell = false;
    for (let i = 0; i <= lastClosed; i++) {
      const b = bars[i];
      const dk = Math.floor(b.time / 86400), hour = Math.floor((b.time % 86400) / 3600);
      if (dk !== day) { day = dk; hi = -Infinity; lo = Infinity; cnt = 0; rng = null; doneBuy = false; doneSell = false; }
      let win = false;
      if (usable) {
        if (hour < ASIA_END) { hi = Math.max(hi, b.high); lo = Math.min(lo, b.low); cnt++; }
        else {
          if (!rng && cnt >= expected * 0.5 && hi > lo) rng = { hi, lo };
          win = hour < LON_END;
          if (rng && win && atr[i] != null && rng.hi - rng.lo >= 0.5 * atr[i]) {
            const buf = atr[i] * p.slBuf;
            const up = b.high > rng.hi && b.close < rng.hi, dn = b.low < rng.lo && b.close > rng.lo;
            if (up && !dn && !doneSell) { sig[i] = { side: 'sell', sl: b.high + buf, level: rng.hi }; doneSell = true; }
            else if (dn && !up && !doneBuy) { sig[i] = { side: 'buy', sl: b.low - buf, level: rng.lo }; doneBuy = true; }
          }
        }
      }
      state[i] = { usable, rng, win };
    }
    const conds = (i, side, fmt) => {
      const s = sgn(side), st = state[i] || {};
      const hit = sig[i] && sig[i].side === side;
      return [
        { label: 'มีกรอบเอเชีย 07:00–14:00 น. ' + (st.rng ? fmt(st.rng.lo) + ' – ' + fmt(st.rng.hi) : st.usable === false ? '(ใช้ได้เฉพาะ 5m / 15m / 1H)' : '(ยังไม่มี)'), ok: !!st.rng },
        { label: 'อยู่ในช่วงลอนดอน 14:00–19:00 น.', ok: !!st.win },
        { label: s > 0 ? 'ไส้กวาดใต้กรอบเอเชียแล้วปิดกลับเข้ากรอบ' : 'ไส้กวาดเหนือกรอบเอเชียแล้วปิดกลับเข้ากรอบ', ok: !!hit },
      ];
    };
    const lines = [];
    if (rng && bars[lastClosed] && Math.floor(bars[lastClosed].time / 86400) === day) {
      lines.push({ price: rng.hi, title: 'ASIA H', color: GOLD });
      lines.push({ price: rng.lo, title: 'ASIA L', color: GOLD });
    }
    return { state, sig, conds, lines };
  }

  const api = { bos: bosEngine, ob: obEngine, fvg: fvgEngine, asia: asiaEngine };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PA = api;
})(typeof window !== 'undefined' ? window : globalThis);
