(() => {
  const SD = window.SD; if (!SD) return;
  const $ = (id) => document.getElementById(id);
  const body = $('tgBody'), stateEl = $('tgState');
  const TF = { '5m': '5m', '15m': '15m', '1h': '1H', '4h': '4H', '1d': '1D' };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let st = null, busy = false;

  async function api(path, data) {
    const res = await fetch(`${SD.API}/api/tg/${path}`, data === undefined ? {} : {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
    });
    let j = {}; try { j = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error(j.detail || `HTTP ${res.status}`);
    return j;
  }
  const SN = { sweep: 'Liquidity Sweep', bos: 'BOS + Retest', ob: 'Order Block', fvg: 'FVG', asia: 'Asian Range Sweep' };
  const isPA = (s) => !!SN[s];
  const sweepParams = (p) => ({ strategy: p.strategy, swing: p.swing, confirm: p.confirm, rr: p.rr, slBuf: p.slBuf, allowShort: p.allowShort });
  const watching = () => { const c = SD.ctx(); return st && st.watches.find((w) => w.symbol === c.symbol && w.interval === c.interval); };

  async function refresh() {
    try { st = await api('status'); } catch (e) { st = null; }
    render();
  }

  async function act(fn, okMsg) {
    if (busy) return; busy = true;
    body.querySelectorAll('button,input').forEach((el) => (el.disabled = true));
    try { const r = await fn(); if (okMsg) SD.toast(typeof okMsg === 'function' ? okMsg(r) : okMsg); await refresh(); }
    catch (e) { SD.toast(e.message); render(); }
    finally { busy = false; }
  }

  function render() {
    if (!st) {
      stateEl.textContent = 'ออฟไลน์'; stateEl.className = 'tg-state muted';
      body.innerHTML = '<p class="hint" style="margin:0">ติดต่อเซิร์ฟเวอร์แจ้งเตือนไม่ได้ <button class="btn-ghost" id="tgRetry">ลองใหม่</button></p>';
      $('tgRetry').onclick = refresh; return;
    }
    // step 1: bot token
    if (!st.hasToken) {
      stateEl.textContent = 'ยังไม่เชื่อม'; stateEl.className = 'tg-state muted';
      body.innerHTML = `
        <ol class="tg-steps">
          <li>เปิด <a href="https://t.me/BotFather" target="_blank" rel="noopener">@BotFather</a> ใน Telegram แล้วพิมพ์ <code>/newbot</code></li>
          <li>ตั้งชื่อบอท แล้วคัดลอก Bot Token ที่ได้มาวางด้านล่าง</li>
        </ol>
        <div class="tg-row"><input type="password" id="tgToken" placeholder="123456789:AA…" autocomplete="off" spellcheck="false" aria-label="Bot Token"><button class="btn-primary" id="tgSave">เชื่อมบอท</button></div>
        <p class="hint">Token เก็บไว้ที่เซิร์ฟเวอร์ของแอปเท่านั้น ไม่แสดงกลับบนหน้าเว็บ</p>`;
      $('tgSave').onclick = () => { const v = $('tgToken').value.trim(); if (!v) return; act(() => api('token', { token: v }), (r) => `เชื่อมบอท @${r.bot} แล้ว`); };
      return;
    }
    // step 2: link chat
    if (!st.linked) {
      stateEl.textContent = 'รอเชื่อมแชต'; stateEl.className = 'tg-state warn';
      body.innerHTML = `
        <ol class="tg-steps" start="3">
          <li>เปิดแชตกับ <a href="https://t.me/${esc(st.bot)}" target="_blank" rel="noopener">@${esc(st.bot)}</a> แล้วกด Start (หรือพิมพ์ <code>/start</code>)</li>
          <li>กลับมากดปุ่มด้านล่าง</li>
        </ol>
        <div class="tg-row"><button class="btn-primary" id="tgLink">ตรวจหาแชต</button>${st.fromEnv ? '' : '<button class="btn-ghost" id="tgOff">เปลี่ยนบอท</button>'}</div>`;
      $('tgLink').onclick = () => act(() => api('link', {}), (r) => `เชื่อมกับแชต ${r.chat} แล้ว`);
      if ($('tgOff')) $('tgOff').onclick = () => act(() => api('disconnect', {}));
      return;
    }
    // step 3: watches
    const c = SD.ctx(), names = SD.names(), on = watching(), sweep = isPA(c.p.strategy);
    stateEl.textContent = st.watches.length ? `เฝ้า ${st.watches.length} รายการ` : 'เชื่อมแล้ว'; stateEl.className = 'tg-state ok';
    const cur = `${names[c.symbol]} · ${TF[c.interval]}`;
    const list = st.watches.length ? st.watches.map((w) => `
        <li><span class="mono">${esc(names[w.symbol] || w.symbol)} · ${TF[w.interval]}</span><span class="muted">${esc(SN[w.params.strategy] || SN.sweep)} · RR 1:${w.params.rr}</span>
        <button class="tg-x" data-s="${w.symbol}" data-i="${w.interval}" aria-label="หยุดเฝ้า ${esc(w.symbol)} ${w.interval}">หยุด</button></li>`).join('')
      : '<li class="muted">ยังไม่ได้เฝ้าคู่ไหน</li>';
    const sent = (st.sent || []).slice(0, 3).map((s) => `<li><span class="pill ${s.side}">${s.side === 'buy' ? 'BUY' : 'SELL'}</span> <span class="mono">${esc(names[s.symbol] || s.symbol)} ${TF[s.interval]}</span> <span class="muted">${new Date(s.sentAt * 1000).toLocaleString('th-TH', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false })}</span></li>`).join('');
    body.innerHTML = `
      <button class="tg-toggle ${on ? 'on' : ''}" id="tgToggle" ${sweep ? '' : 'disabled'}>
        <span class="tg-sw" aria-hidden="true"></span>
        <span>${on ? 'กำลังส่ง' : 'ส่ง'}สัญญาณ <b>${esc(cur)}</b>${sweep ? ' · ' + esc(SN[c.p.strategy]) : ''} เข้า Telegram</span>
      </button>
      ${sweep ? '' : '<p class="hint">ระบบแจ้งเตือนรองรับเฉพาะ Liquidity Sweep, BOS + Retest, Order Block, FVG และ Asian Range Sweep</p>'}
      <ul class="tg-list">${list}</ul>
      ${sent ? `<div class="muted" style="margin-top:10px">ส่งล่าสุด</div><ul class="tg-list sent">${sent}</ul>` : ''}
      <div class="tg-row" style="margin-top:10px"><button class="btn-ghost" id="tgTest">ส่งข้อความทดสอบ</button>${st.fromEnv ? '' : '<button class="btn-ghost" id="tgOff">ยกเลิกการเชื่อม</button>'}</div>
      <p class="hint">บอท @${esc(st.bot)} ตรวจทุก ${st.checkEvery} วินาที ส่งเมื่อแท่งเทียนปิดแล้วเกิดสัญญาณ ทำงานแม้ปิดหน้าเว็บ${st.lastError ? `<br><span class="down">ข้อผิดพลาดล่าสุด: ${esc(st.lastError)}</span>` : ''}</p>`;
    $('tgToggle').onclick = () => act(() => api('watch', { symbol: c.symbol, interval: c.interval, params: sweepParams(c.p), on: !on }), on ? `หยุดเฝ้า ${cur}` : `เริ่มเฝ้า ${cur} แล้ว`);
    $('tgTest').onclick = () => act(() => api('test', {}), 'ส่งข้อความทดสอบแล้ว เช็กใน Telegram');
    if ($('tgOff')) $('tgOff').onclick = () => { if (confirm('ยกเลิกการเชื่อม Telegram และลบ Token?')) act(() => api('disconnect', {}), 'ยกเลิกการเชื่อมแล้ว'); };
    body.querySelectorAll('.tg-x').forEach((b) => (b.onclick = () => act(() => api('watch', { symbol: b.dataset.s, interval: b.dataset.i, on: false }), 'หยุดเฝ้าแล้ว')));
  }

  document.addEventListener('sd:change', () => { if (!busy) render(); });
  // keep the server-side watch in sync with sweep settings for the current chart
  document.addEventListener('sd:params', () => {
    const w = watching(), c = SD.ctx();
    if (!w || !isPA(c.p.strategy)) { render(); return; }
    act(() => api('watch', { symbol: c.symbol, interval: c.interval, params: sweepParams(c.p), on: true }), 'อัปเดตค่าการแจ้งเตือนแล้ว');
  });
  refresh();
  setInterval(() => { if (!busy && document.visibilityState === 'visible') refresh(); }, 60000);
})();
