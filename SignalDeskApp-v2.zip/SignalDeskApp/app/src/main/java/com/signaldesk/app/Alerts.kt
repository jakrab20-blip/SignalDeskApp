package com.signaldesk.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

// พอร์ตจาก alerts.py: ตั้งค่า, Telegram, ตรวจสัญญาณ
// ต่างจากต้นฉบับ 2 จุด: เก็บ baseline ไว้ในเครื่อง (ไม่หายเมื่อบริการถูกรีสตาร์ท) และมีแจ้งเตือนบนมือถือเมื่อเจอสัญญาณ
object Alerts {
    private val lock = Any()
    private lateinit var appCtx: Context
    private lateinit var prefs: SharedPreferences

    private var token = ""
    private var chatId = ""
    private var bot = ""
    private val watches = ArrayList<Watch>()
    private val baseline = HashMap<String, Long>()

    private var lastCheck: Long? = null
    @Volatile private var lastError: String? = null
    private val sent = ArrayList<JSONObject>()

    @Volatile var listener: (() -> Unit)? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        prefs = appCtx.getSharedPreferences("signaldesk", Context.MODE_PRIVATE)
        synchronized(lock) {
            token = prefs.getString("token", "") ?: ""
            chatId = prefs.getString("chat_id", "") ?: ""
            bot = prefs.getString("bot", "") ?: ""
            try {
                val arr = JSONArray(prefs.getString("watches", "[]"))
                watches.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    watches.add(Watch(o.getString("symbol"), o.getString("interval"), Params.fromJson(o.optJSONObject("params"))))
                }
                val b = JSONObject(prefs.getString("baseline", "{}"))
                baseline.clear()
                for (k in b.keys()) baseline[k] = b.getLong(k)
            } catch (e: Exception) {
                lastError = "อ่านไฟล์ตั้งค่าไม่ได้: ${e.message}"
            }
        }
    }

    // ---------------------------------------------------------------- เก็บค่า
    private fun saveConfig() {
        val arr = JSONArray()
        watches.forEach { arr.put(it.toJson()) }
        prefs.edit()
            .putString("token", token)
            .putString("chat_id", chatId)
            .putString("bot", bot)
            .putString("watches", arr.toString())
            .apply()
    }

    private fun saveBaseline() {
        val o = JSONObject()
        baseline.forEach { (k, v) -> o.put(k, v) }
        prefs.edit().putString("baseline", o.toString()).apply()
    }

    fun watchCount(): Int = synchronized(lock) { watches.size }

    fun recordError(msg: String) {
        lastError = msg
    }

    // ---------------------------------------------------------------- Telegram
    private fun tgRaw(tok: String, method: String, params: Map<String, String>): Any {
        if (tok.isEmpty()) throw IllegalStateException("ยังไม่ได้ตั้งค่า Bot Token")
        val (code, body) = Http.postForm("https://api.telegram.org/bot$tok/$method", params)
        val out = try {
            JSONObject(body)
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("description", "HTTP $code")
        }
        if (!out.optBoolean("ok", false)) throw TgException(out.optString("description", "Telegram error"))
        return out.get("result")
    }

    fun send(text: String) {
        val (t, c) = synchronized(lock) { Pair(token, chatId) }
        tgRaw(t, "sendMessage", mapOf("chat_id" to c, "text" to text, "parse_mode" to "HTML", "disable_web_page_preview" to "true"))
    }

    fun setToken(raw: String): String {
        val tok = raw.trim()
        val me = try {
            tgRaw(tok, "getMe", emptyMap()) as JSONObject
        } catch (e: TgException) {
            val m = e.message ?: ""
            throw IllegalStateException(
                if (m.contains("nauthorized") || m.contains("Not Found"))
                    "Token ไม่ถูกต้อง ตรวจสอบว่าคัดลอกครบจาก @BotFather" else m
            )
        }
        return synchronized(lock) {
            if (token != tok) chatId = ""
            token = tok
            bot = me.optString("username", "")
            saveConfig()
            bot
        }
    }

    fun linkChat(): String? {
        val tok = synchronized(lock) { token }
        val ups = tgRaw(tok, "getUpdates", mapOf("limit" to "50", "timeout" to "0")) as JSONArray
        for (i in ups.length() - 1 downTo 0) {
            val u = ups.getJSONObject(i)
            val m = u.optJSONObject("message") ?: u.optJSONObject("channel_post") ?: JSONObject()
            val c = m.optJSONObject("chat") ?: continue
            val id = c.getLong("id").toString()
            synchronized(lock) {
                chatId = id
                saveConfig()
            }
            val name = c.optString("first_name", "").ifEmpty { c.optString("title", "") }.ifEmpty { c.optString("username", "") }
            return name.ifEmpty { id }
        }
        return null
    }

    fun disconnect() {
        synchronized(lock) {
            token = ""
            chatId = ""
            bot = ""
            saveConfig()
        }
    }

    // ---------------------------------------------------------------- รายการที่เฝ้า
    private fun key(w: Watch) = "${w.symbol}|${w.interval}"

    fun setWatch(symbol: String, interval: String, params: JSONObject?, on: Boolean): List<Watch> {
        if (!Cfg.NAMES.containsKey(symbol) || !Cfg.DUR.containsKey(interval)) {
            throw IllegalArgumentException("unsupported symbol or interval")
        }
        val strat = params?.optString("strategy", "sweep") ?: "sweep"
        if (!Cfg.STRATEGIES.contains(strat)) throw IllegalArgumentException("unsupported strategy")
        val p = Params.fromJson(params)
        val result = synchronized(lock) {
            watches.removeAll { it.symbol == symbol && it.interval == interval }
            baseline.remove("$symbol|$interval")
            if (on) watches.add(Watch(symbol, interval, p))
            saveConfig()
            saveBaseline()
            watches.toList()
        }
        MonitorService.sync(appCtx)
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
        return result
    }

    // ---------------------------------------------------------------- ตรวจสัญญาณ
    fun checkOnce() {
        val ws = synchronized(lock) { watches.toList() }
        for (w in ws) {
            val k = key(w)
            try {
                val bars = Market.fetchBars(w.symbol, w.interval)
                if (bars.size < 50) continue
                var sigs = Engine.signals(bars, w)
                if (!w.params.allowShort) sigs = sigs.filter { it.side == "buy" }
                val latest = sigs.lastOrNull()?.time ?: 0L

                val base = synchronized(lock) { baseline[k] }
                if (base == null) { // ดูครั้งแรก: จำไว้ ไม่ส่งย้อนหลัง
                    synchronized(lock) {
                        baseline[k] = latest
                        saveBaseline()
                    }
                    continue
                }

                val fresh = sigs.filter { it.time > base && it.idx >= bars.size - 3 }
                var cur: Long = base
                for (s in fresh) {
                    Notifier.signal(appCtx, Engine.notificationTitle(w, s), Engine.notificationText(w, s))
                    val linked = synchronized(lock) { chatId.isNotEmpty() }
                    if (linked) send(Engine.formatSignal(w, s))
                    synchronized(lock) {
                        sent.add(
                            0,
                            JSONObject().put("symbol", w.symbol).put("interval", w.interval).put("side", s.side)
                                .put("price", s.price).put("sl", s.sl).put("tp", s.tp).put("time", s.time)
                                .put("sentAt", System.currentTimeMillis() / 1000)
                        )
                        while (sent.size > 30) sent.removeAt(sent.size - 1)
                        cur = maxOf(cur, s.time)
                        baseline[k] = cur
                        saveBaseline()
                    }
                }
                synchronized(lock) {
                    baseline[k] = maxOf(baseline[k] ?: base, latest)
                    saveBaseline()
                }
                lastError = null
            } catch (e: Exception) {
                lastError = "${w.symbol} ${w.interval}: ${e.message}"
            }
        }
        lastCheck = System.currentTimeMillis() / 1000
    }

    // ---------------------------------------------------------------- สถานะให้หน้าเว็บ
    fun status(): JSONObject {
        return synchronized(lock) {
            val ws = JSONArray()
            watches.forEach { ws.put(it.toJson()) }
            val sn = JSONArray()
            sent.take(10).forEach { sn.put(it) }
            JSONObject()
                .put("hasToken", token.isNotEmpty())
                .put("bot", bot)
                .put("linked", chatId.isNotEmpty())
                .put("fromEnv", false)
                .put("watches", ws)
                .put("lastCheck", lastCheck ?: JSONObject.NULL)
                .put("lastError", lastError ?: JSONObject.NULL)
                .put("sent", sn)
                .put("checkEvery", Cfg.CHECK_EVERY)
        }
    }
}
