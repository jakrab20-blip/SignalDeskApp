package com.signaldesk.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

// พอร์ตตรง ๆ จาก alerts.py (atr, sweep_signals, format_signal)
object Engine {

    private class Lvl(val price: Double, val idx: Int, var used: Boolean = false)
    private class Pend(val side: String, val lvl: Lvl, var ext: Double, val start: Int)
    private class Fired(val side: String, val sl: Double, val level: Double)

    fun atr(bars: List<Bar>, p: Int = 14): Array<Double?> {
        val out = arrayOfNulls<Double>(bars.size)
        var prev = 0.0
        var s = 0.0
        for (i in 1 until bars.size) {
            val b = bars[i]
            val pc = bars[i - 1].close
            val tr = maxOf(b.high - b.low, abs(b.high - pc), abs(b.low - pc))
            if (i <= p) {
                s += tr
                if (i == p) {
                    prev = s / p
                    out[i] = prev
                }
            } else {
                prev = (prev * (p - 1) + tr) / p
                out[i] = prev
            }
        }
        return out
    }

    fun sweepSignals(bars: List<Bar>, p: Params): List<Signal> {
        val n = maxOf(2, p.swing)
        val k = maxOf(0, p.confirm)
        val a = atr(bars)
        var sh: Lvl? = null
        var sl: Lvl? = null
        var pend: Pend? = null
        var struct = 0
        val sigs = ArrayList<Signal>()

        fun isPh(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].high >= bars[j].high else bars[kk].high > bars[j].high
                    if (bad) return false
                }
            }
            return true
        }

        fun isPl(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].low <= bars[j].low else bars[kk].low < bars[j].low
                    if (bad) return false
                }
            }
            return true
        }

        for (i in bars.indices) {
            val b = bars[i]
            val j = i - n
            if (j >= n) {
                if (isPh(j)) sh = Lvl(bars[j].high, j)
                if (isPl(j)) sl = Lvl(bars[j].low, j)
            }
            val buf = (a[i] ?: 0.0) * p.slBuf

            val curSh = sh
            val curSl = sl
            if (pend == null && struct == 1 && curSl != null && !curSl.used && b.low < curSl.price) {
                pend = Pend("buy", curSl, b.low, i)
                curSl.used = true
            } else if (pend == null && struct == -1 && curSh != null && !curSh.used && b.high > curSh.price) {
                pend = Pend("sell", curSh, b.high, i)
                curSh.used = true
            }

            var fired: Fired? = null
            val pd = pend
            if (pd != null) {
                if (pd.side == "buy") {
                    pd.ext = minOf(pd.ext, b.low)
                    if (b.close > pd.lvl.price) {
                        fired = Fired("buy", pd.ext - buf, pd.lvl.price)
                        pend = null
                    } else if (i - pd.start >= k) {
                        struct = -1
                        pend = null
                    }
                } else {
                    pd.ext = maxOf(pd.ext, b.high)
                    if (b.close < pd.lvl.price) {
                        fired = Fired("sell", pd.ext + buf, pd.lvl.price)
                        pend = null
                    } else if (i - pd.start >= k) {
                        struct = 1
                        pend = null
                    }
                }
            }

            if (pend == null && fired == null) {
                if (curSh != null && b.close > curSh.price && struct != 1) {
                    struct = 1
                } else if (curSl != null && b.close < curSl.price && struct != -1) {
                    struct = -1
                }
            }

            val ai = a[i]
            val f = fired
            if (f != null && ai != null && i >= 2) {
                val d = if (f.side == "buy") 1 else -1
                val entry = b.close
                sigs.add(
                    Signal(
                        f.side, f.sl, f.level, b.time, i, entry,
                        entry + d * p.rr * abs(entry - f.sl), ai
                    )
                )
            }
        }
        return sigs
    }

    // ------------------------------------------------------------------
    // ระบบราคาล้วนเพิ่มเติม (พอร์ตตรงจาก engines.js — ค่าคงที่ต้องตรงกัน)
    // ------------------------------------------------------------------
    private const val RETEST = 20
    private const val OB_BODY = 1.5
    private const val OB_BACK = 10
    private const val OB_LIFE = 50
    private const val FVG_MIN = 0.5
    private const val FVG_LIFE = 50
    private const val ASIA_END = 7
    private const val LON_END = 12

    private class Zone(val dir: Int, val top: Double, val bottom: Double, val born: Int) {
        var used = false
    }

    private class BosPend(val dir: Int, val level: Double, val inval: Double, var ext: Double, val start: Int)

    private class Piv(private val bars: List<Bar>, private val n: Int) {
        var sh: Lvl? = null
        var sl: Lvl? = null

        private fun isPh(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].high >= bars[j].high else bars[kk].high > bars[j].high
                    if (bad) return false
                }
            }
            return true
        }

        private fun isPl(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].low <= bars[j].low else bars[kk].low < bars[j].low
                    if (bad) return false
                }
            }
            return true
        }

        fun step(i: Int) {
            val j = i - n
            if (j >= n) {
                if (isPh(j)) sh = Lvl(bars[j].high, j)
                if (isPl(j)) sl = Lvl(bars[j].low, j)
            }
        }
    }

    private fun emit(out: MutableList<Signal>, i: Int, b: Bar, a: Array<Double?>, p: Params, f: Fired?) {
        val ai = a[i]
        if (f != null && ai != null && i >= 2) {
            val d = if (f.side == "buy") 1 else -1
            out.add(
                Signal(f.side, f.sl, f.level, b.time, i, b.close, b.close + d * p.rr * abs(b.close - f.sl), ai)
            )
        }
    }

    fun signals(bars: List<Bar>, w: Watch): List<Signal> = when (w.params.strategy) {
        "bos" -> bosSignals(bars, w.params)
        "ob" -> obSignals(bars, w.params)
        "fvg" -> fvgSignals(bars, w.params)
        "asia" -> asiaSignals(bars, w.params, Cfg.DUR.getValue(w.interval))
        else -> sweepSignals(bars, w.params)
    }

    private fun bosSignals(bars: List<Bar>, p: Params): List<Signal> {
        val a = atr(bars)
        val pv = Piv(bars, maxOf(2, p.swing))
        var pend: BosPend? = null
        val out = ArrayList<Signal>()
        for (i in bars.indices) {
            val b = bars[i]
            pv.step(i)
            val buf = (a[i] ?: 0.0) * p.slBuf
            var fired: Fired? = null
            val pd = pend
            if (pd != null) {
                if (pd.dir == 1) {
                    pd.ext = minOf(pd.ext, b.low)
                    if (b.low <= pd.level && b.close > pd.level) {
                        fired = Fired("buy", pd.ext - buf, pd.level)
                        pend = null
                    } else if (b.close < pd.inval || i - pd.start > RETEST) {
                        pend = null
                    }
                } else {
                    pd.ext = maxOf(pd.ext, b.high)
                    if (b.high >= pd.level && b.close < pd.level) {
                        fired = Fired("sell", pd.ext + buf, pd.level)
                        pend = null
                    } else if (b.close > pd.inval || i - pd.start > RETEST) {
                        pend = null
                    }
                }
            }
            if (pend == null && fired == null) {
                val sh = pv.sh
                val sl = pv.sl
                if (sh != null && !sh.used && b.close > sh.price) {
                    sh.used = true
                    pend = BosPend(1, sh.price, sl?.price ?: b.low, Double.POSITIVE_INFINITY, i)
                } else if (sl != null && !sl.used && b.close < sl.price) {
                    sl.used = true
                    pend = BosPend(-1, sl.price, sh?.price ?: b.high, Double.NEGATIVE_INFINITY, i)
                }
            }
            emit(out, i, b, a, p, fired)
        }
        return out
    }

    private fun obSignals(bars: List<Bar>, p: Params): List<Signal> {
        val a = atr(bars)
        val pv = Piv(bars, maxOf(2, p.swing))
        val zones = ArrayList<Zone>()
        val out = ArrayList<Signal>()
        for (i in bars.indices) {
            val b = bars[i]
            pv.step(i)
            val buf = (a[i] ?: 0.0) * p.slBuf
            zones.removeAll { i - it.born > OB_LIFE || (if (it.dir == 1) b.close < it.bottom else b.close > it.top) }
            var fired: Fired? = null
            for (z in zones) {
                if (z.dir == 1 && b.low <= z.top && b.close > z.top) {
                    fired = Fired("buy", minOf(z.bottom, b.low) - buf, z.top)
                    z.used = true
                    break
                }
                if (z.dir == -1 && b.high >= z.bottom && b.close < z.bottom) {
                    fired = Fired("sell", maxOf(z.top, b.high) + buf, z.bottom)
                    z.used = true
                    break
                }
            }
            if (fired != null) zones.removeAll { it.used }
            val ai = a[i]
            if (ai != null && abs(b.close - b.open) >= OB_BODY * ai) {
                val sh = pv.sh
                val sl = pv.sl
                if (b.close > b.open && sh != null && !sh.used && b.close > sh.price) {
                    sh.used = true
                    for (k in (i - 1) downTo maxOf(0, i - OB_BACK)) {
                        if (bars[k].close < bars[k].open) {
                            zones.add(Zone(1, bars[k].high, bars[k].low, i))
                            break
                        }
                    }
                } else if (b.close < b.open && sl != null && !sl.used && b.close < sl.price) {
                    sl.used = true
                    for (k in (i - 1) downTo maxOf(0, i - OB_BACK)) {
                        if (bars[k].close > bars[k].open) {
                            zones.add(Zone(-1, bars[k].high, bars[k].low, i))
                            break
                        }
                    }
                }
            }
            emit(out, i, b, a, p, fired)
        }
        return out
    }

    private fun fvgSignals(bars: List<Bar>, p: Params): List<Signal> {
        val a = atr(bars)
        val pv = Piv(bars, maxOf(2, p.swing))
        val zones = ArrayList<Zone>()
        val out = ArrayList<Signal>()
        var struct = 0
        for (i in bars.indices) {
            val b = bars[i]
            pv.step(i)
            val sh0 = pv.sh
            val sl0 = pv.sl
            if (sh0 != null && b.close > sh0.price && struct != 1) {
                struct = 1
            } else if (sl0 != null && b.close < sl0.price && struct != -1) {
                struct = -1
            }
            val buf = (a[i] ?: 0.0) * p.slBuf
            zones.removeAll { i - it.born > FVG_LIFE || (if (it.dir == 1) b.close < it.bottom else b.close > it.top) }
            var fired: Fired? = null
            for (z in zones) {
                val mid = (z.top + z.bottom) / 2
                if (z.dir == 1 && b.low <= z.top && b.close > mid) {
                    fired = Fired("buy", minOf(z.bottom, b.low) - buf, z.top)
                    z.used = true
                    break
                }
                if (z.dir == -1 && b.high >= z.bottom && b.close < mid) {
                    fired = Fired("sell", maxOf(z.top, b.high) + buf, z.bottom)
                    z.used = true
                    break
                }
            }
            if (fired != null) zones.removeAll { it.used }
            val ai = a[i]
            if (ai != null && i >= 2) {
                val gapUp = b.low - bars[i - 2].high
                val gapDn = bars[i - 2].low - b.high
                if (gapUp >= FVG_MIN * ai && struct == 1) {
                    zones.add(Zone(1, b.low, bars[i - 2].high, i))
                } else if (gapDn >= FVG_MIN * ai && struct == -1) {
                    zones.add(Zone(-1, bars[i - 2].low, b.high, i))
                }
            }
            emit(out, i, b, a, p, fired)
        }
        return out
    }

    private fun asiaSignals(bars: List<Bar>, p: Params, dur: Long): List<Signal> {
        val out = ArrayList<Signal>()
        if (dur > 3600L) return out
        val a = atr(bars)
        val expected = (ASIA_END * 3600L / dur).toInt()
        var day = Long.MIN_VALUE
        var hi = Double.NEGATIVE_INFINITY
        var lo = Double.POSITIVE_INFINITY
        var cnt = 0
        var rng: DoubleArray? = null // [สูง, ต่ำ] ของกรอบเอเชียวันนี้
        var doneBuy = false
        var doneSell = false
        for (i in bars.indices) {
            val b = bars[i]
            val dk = Math.floorDiv(b.time, 86400L)
            val hour = (Math.floorMod(b.time, 86400L) / 3600L).toInt()
            if (dk != day) {
                day = dk
                hi = Double.NEGATIVE_INFINITY
                lo = Double.POSITIVE_INFINITY
                cnt = 0
                rng = null
                doneBuy = false
                doneSell = false
            }
            if (hour < ASIA_END) {
                hi = maxOf(hi, b.high)
                lo = minOf(lo, b.low)
                cnt++
                continue
            }
            if (rng == null && cnt >= expected * 0.5 && hi > lo) rng = doubleArrayOf(hi, lo)
            val r = rng
            val ai = a[i]
            var fired: Fired? = null
            if (r != null && hour < LON_END && ai != null && r[0] - r[1] >= 0.5 * ai) {
                val buf = ai * p.slBuf
                val up = b.high > r[0] && b.close < r[0]
                val dn = b.low < r[1] && b.close > r[1]
                if (up && !dn && !doneSell) {
                    fired = Fired("sell", b.high + buf, r[0])
                    doneSell = true
                } else if (dn && !up && !doneBuy) {
                    fired = Fired("buy", b.low - buf, r[1])
                    doneBuy = true
                }
            }
            emit(out, i, b, a, p, fired)
        }
        return out
    }

    private fun strategyShort(s: String): String = when (s) {
        "bos" -> "BOS"
        "ob" -> "OB"
        "fvg" -> "FVG"
        "asia" -> "ASIA"
        else -> "SWEEP"
    }

    private fun fmt(v: Double, digits: Int): String = String.format(Locale.US, "%,.${digits}f", v)

    private fun dist(symbol: String, d: Double): String {
        val info = Cfg.NAMES.getValue(symbol)
        return if (info.metal) String.format(Locale.US, "\$%.2f", abs(d))
        else String.format(Locale.US, "%.1f pips", abs(d) / info.pip)
    }

    // เหมือน Python {rr:g}: 2.0 -> "2", 1.5 -> "1.5"
    private fun fmtG(v: Double): String = v.toString().removeSuffix(".0")

    private fun headline(w: Watch, s: Signal, lvl: String, digits: Int): String {
        val v = fmt(s.level, digits)
        return when (w.params.strategy) {
            "bos" -> "BOS + Retest — ทดสอบระดับ $v แล้วปิดกลับตามเทรนด์"
            "ob" -> "Order Block — แตะโซน OB ที่ $v แล้วปิดกลับ"
            "fvg" -> "FVG — แตะช่องว่างราคาที่ $v แล้วปิดกลับ"
            "asia" -> "Asian Range Sweep — กวาดกรอบเอเชียที่ $v แล้วปิดกลับเข้ากรอบ"
            else -> "Liquidity Sweep — กวาด $lvl ที่ $v แล้วปิดกลับ"
        }
    }

    fun formatSignal(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        val side = if (s.side == "buy") "BUY" else "SELL"
        val lvl = if (s.side == "buy") "SSL" else "BSL"
        val dur = Cfg.DUR.getValue(w.interval)
        val sdf = SimpleDateFormat("dd/MM HH:mm", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        val t = sdf.format(Date((s.time + dur + 7 * 3600) * 1000))
        return "<b>$side ${info.name}</b> · ${w.interval.uppercase()}\n" +
            headline(w, s, lvl, info.digits) + "\n\n" +
            "เข้า: <code>${fmt(s.price, info.digits)}</code>\n" +
            "SL: <code>${fmt(s.sl, info.digits)}</code> (${dist(w.symbol, s.price - s.sl)})\n" +
            "TP: <code>${fmt(s.tp, info.digits)}</code> (${dist(w.symbol, s.tp - s.price)})\n" +
            "R:R 1:${fmtG(w.params.rr)}\n\n" +
            "แท่งปิด $t (เวลาไทย)\n" +
            "<i>SignalDesk · ไม่ใช่คำแนะนำการลงทุน</i>"
    }

    fun notificationTitle(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        return "${if (s.side == "buy") "BUY" else "SELL"} ${info.name} · ${w.interval.uppercase()} · ${strategyShort(w.params.strategy)}"
    }

    fun notificationText(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        return "เข้า ${fmt(s.price, info.digits)} · SL ${fmt(s.sl, info.digits)} · TP ${fmt(s.tp, info.digits)}"
    }
}
