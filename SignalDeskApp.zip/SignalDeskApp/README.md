# SignalDesk (Android)
หน้าเว็บ SignalDesk เดิม (ใน app/src/main/assets/web) แสดงผลใน WebView
และมีตัวตรวจสัญญาณ Liquidity Sweep เขียนด้วย Kotlin ทำงานเป็น Foreground Service
- ตรวจทุก 30 วินาที แม้ปิดแอป ส่งเข้า Telegram และแจ้งเตือนบนมือถือ
- ตั้งค่า Token / เชื่อมแชต / เลือกคู่ที่เฝ้า ผ่านแผง Telegram ในหน้าเว็บเดิม
- เซิร์ฟเวอร์เล็ก 127.0.0.1:8765 ในแอป แทน server.py
