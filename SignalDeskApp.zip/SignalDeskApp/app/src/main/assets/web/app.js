(() => {
  const REST = 'https://data-api.binance.vision/api/v3/klines';
  const WS = 'wss://data-stream.binance.vision/ws/';
  const TZ = -new Date().getTimezoneOffset() * 60;
  const rawApi = window.__API_BASE__ || '';
  const API = rawApi.startsWith('__PORT_') ? 'http://localhost:8000' : rawApi.replace(/\/$/, '');
  const DUR = { '15m': 900, '1h': 3600, '4h': 14400, '1d': 86400 };
  const fx = (name, digits, pip) => ({ name, src: 'yahoo', digits, pip, unit: 'pips' });
  const INSTR = {
    XAUUSD: { name: 'XAU / USD', src: 'binance', bsym: 'PAXGUSDT', digits: 2, pip: 0.1, metal: true, note: 'เรียลไทม์ · อ้างอิง PAXG' },
    GC: { name: 'Gold Futures', src: 'yahoo', digits: 1, pip: 0.1, metal: true, note: 'COMEX · ล่าช้า ~10 นาที' },
    SI: { name: 'Silver Futures', src: 'yahoo', digits: 3, pip: 0.01, metal: true, note: 'COMEX · ล่าช้า ~10 นาที' },
    EURUSD: fx('EUR / USD', 5, 0.0001), GBPUSD: fx('GBP / USD', 5, 0.0001), USDJPY: fx('USD / JPY', 3, 0.01),
    AUDUSD: fx('AUD / USD', 5, 0.0001), USDCAD: fx('USD / CAD', 5, 0.0001), USDCHF: fx('USD / CHF', 5, 0.0001),
    NZDUSD: fx('NZD / USD', 5, 0.0001), EURJPY: fx('EUR / JPY', 3, 0.01), GBPJPY: fx('GBP / JPY', 3, 0.01),
    EURGBP: fx('EUR / GBP', 5, 0.0001), AUDJPY: fx('AUD / JPY', 3, 0.01), USDTHB: fx('USD / THB', 3, 0.01),
  };
  const inst = () => INSTR[state.symbol] || INSTR.XAUUSD;
  const $ = (id) => document.getElementById(id);

  const state = { symbol: 'XAUUSD', interval: '1h', bars: [], ws: null, poll: null, notify: false, lastSignalTime: null, calc: null, priceLines: [] };
  const HINTS = {
    sweep: 'ดูทิศทางจากโครงสร้างราคา: ปิดเหนือ Swing High = ขาขึ้น, ปิดใต้ Swing Low = ขาลง · ขาขึ้น: ไส้เทียนกวาดใต้ Swing Low (SSL) แล้วปิดกลับเหนือ → BUY, SL ใต้ไส้ · ขาลง: กวาดเหนือ Swing High (BSL) แล้วปิดกลับใต้ → SELL, SL เหนือไส้ · ถ้าไม่ปิดกลับภายในจำนวนแท่งที่กำหนด ถือว่าโครงสร้างเปลี่ยนจริง',
    confluence: 'ซื้อเมื่อ EMA หรือ MACD ตัดขึ้น และทุกเงื่อนไขยืนยัน: EMA เร็ว > EMA ช้า, MACD > Signal, RSI ระหว่าง 50 ถึงเขตซื้อมากเกิน ขายใช้เงื่อนไขกลับด้าน',
    ema: 'ซื้อเมื่อ EMA เร็วตัดขึ้นเหนือ EMA ช้า ขายเมื่อตัดลง',
    macd: 'ซื้อเมื่อเส้น MACD ตัดขึ้นเหนือเส้น Signal ขายเมื่อตัดลง',
    rsi: 'ซื้อเมื่อ RSI ฟื้นกลับขึ้นจากเขตขายมากเกิน ขายเมื่อ RSI หลุดลงจากเขตซื้อมากเกิน',
  };

  // ---------- charts ----------
  const css = getComputedStyle(document.documentElement);
  const C = (n) => css.getPropertyValue(n).trim();
  const base = (showTime) => ({
    layout: { background: { type: 'solid', color: 'transparent' }, textColor: C('--muted'), fontFamily: 'IBM Plex Mono, monospace', fontSize: 11 },
    grid: { vertLines: { color: 'rgba(255,255,255,0.035)' }, horzLines: { color: 'rgba(255,255,255,0.035)' } },
    rightPriceScale: { borderColor: C('--line'), minimumWidth: 78 },
    timeScale: { borderColor: C('--line'), visible: showTime, timeVisible: true, secondsVisible: false, rightOffset: 6 },
    crosshair: { mode: 0 },
    autoSize: true,
  });
  const chP = LightweightCharts.createChart($('chartPrice'), base(false));
  const chR = LightweightCharts.createChart($('chartRsi'), base(false));
  const chM = LightweightCharts.createChart($('chartMacd'), base(true));
  const up = C('--up'), dn = C('--down');
  const sCandle = chP.addCandlestickSeries({ upColor: up, downColor: dn, borderVisible: false, wickUpColor: up, wickDownColor: dn });
  const sFast = chP.addLineSeries({ color: '#e8b34a', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
  const sSlow = chP.addLineSeries({ color: '#6ea8fe', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
  const sTrend = chP.addLineSeries({ color: 'rgba(200,200,220,0.45)', lineWidth: 1, lineStyle: 2, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
  const sRsi = chR.addLineSeries({ color: '#c39bff', lineWidth: 1.5, priceLineVisible: false });
  const rsiOb = sRsi.createPriceLine({ price: 70, color: 'rgba(229,83,75,.5)', lineStyle: 2, lineWidth: 1, axisLabelVisible: false });
  const rsiOs = sRsi.createPriceLine({ price: 30, color: 'rgba(38,179,134,.5)', lineStyle: 2, lineWidth: 1, axisLabelVisible: false });
  const sHist = chM.addHistogramSeries({ priceLineVisible: false, lastValueVisible: false });
  const sMacd = chM.addLineSeries({ color: '#6ea8fe', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });
  const sSig = chM.addLineSeries({ color: '#e8b34a', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });

  // sync visible ranges
  const charts = [chP, chR, chM];
  let syncing = false;
  charts.forEach((c) => c.timeScale().subscribeVisibleLogicalRangeChange((r) => {
    if (syncing || !r) return; syncing = true;
    charts.forEach((o) => o !== c && o.timeScale().setVisibleLogicalRange(r));
    syncing = false;
  }));

  // ---------- settings ----------
  const num = (id) => parseFloat($(id).value);
  const params = () => ({
    strategy: $('strategy').value, fast: num('emaFast'), slow: num('emaSlow'), trend: num('emaTrend'),
    rsiLen: num('rsiLen'), ob: num('rsiOb'), os: num('rsiOs'), sl: num('slAtr'), tp: num('tpAtr'), cost: (num('costPct') || 0) / 100, swing: Math.max(2, num('swingLen') | 0), confirm: Math.max(0, num('confirmBars') | 0), rr: num('rrRatio'), slBuf: num('slBuf'),
    allowShort: $('allowShort').checked, trendFilter: $('trendFilter').checked,
  });
  const SKEYS = ['strategy', 'emaFast', 'emaSlow', 'emaTrend', 'rsiLen', 'rsiOb', 'rsiOs', 'slAtr', 'tpAtr', 'costPct', 'swingLen', 'confirmBars', 'rrRatio', 'slBuf', 'allowShort', 'trendFilter', 'symbol'];
  function saveSettings() {
    try {
      const o = {}; SKEYS.forEach((k) => { const el = $(k); o[k] = el.type === 'checkbox' ? el.checked : el.value; });
      o.interval = state.interval; state.saved = o;
    } catch (e) {}
  }
  function loadSettings() {
    try {
      const o = state.saved; if (!o) return;
      SKEYS.forEach((k) => { if (o[k] == null) return; const el = $(k); if (el.type === 'checkbox') el.checked = o[k]; else el.value = o[k]; });
      if (o.interval) state.interval = o.interval;
    } catch (e) {}
  }

  // ---------- engine ----------
  function sweepEngine(bars, atr, lastClosed, p) {
    const N = p.swing, K = p.confirm, state = [], sig = [];
    let sh = null, sl = null, struct = 0, pend = null;
    const isPH = (j) => { for (let k = j - N; k <= j + N; k++) if (k !== j && (k < j ? bars[k].high >= bars[j].high : bars[k].high > bars[j].high)) return false; return true; };
    const isPL = (j) => { for (let k = j - N; k <= j + N; k++) if (k !== j && (k < j ? bars[k].low <= bars[j].low : bars[k].low < bars[j].low)) return false; return true; };
    for (let i = 0; i <= lastClosed; i++) {
      const b = bars[i], j = i - N;
      if (j >= N) {
        if (isPH(j)) sh = { price: bars[j].high, idx: j, used: false };
        if (isPL(j)) sl = { price: bars[j].low, idx: j, used: false };
      }
      const buf = (atr[i] || 0) * p.slBuf;
      // new sweep: wick through the opposite-side liquidity while structure holds
      if (!pend && struct === 1 && sl && !sl.used && b.low < sl.price) { pend = { side: 'buy', lvl: sl, ext: b.low, start: i }; sl.used = true; }
      else if (!pend && struct === -1 && sh && !sh.used && b.high > sh.price) { pend = { side: 'sell', lvl: sh, ext: b.high, start: i }; sh.used = true; }
      if (pend) {
        if (pend.side === 'buy') {
          pend.ext = Math.min(pend.ext, b.low);
          if (b.close > pend.lvl.price) { sig[i] = { side: 'buy', sl: pend.ext - buf, level: pend.lvl.price, from: pend.lvl.idx }; pend = null; }
          else if (i - pend.start >= K) { struct = -1; pend = null; } // no reclaim -> real break down
        } else {
          pend.ext = Math.max(pend.ext, b.high);
          if (b.close < pend.lvl.price) { sig[i] = { side: 'sell', sl: pend.ext + buf, level: pend.lvl.price, from: pend.lvl.idx }; pend = null; }
          else if (i - pend.start >= K) { struct = 1; pend = null; }
        }
      }
      // break of structure (closes beyond the latest swing)
      if (!pend && !sig[i]) {
        if (sh && b.close > sh.price && struct !== 1) struct = 1;
        else if (sl && b.close < sl.price && struct !== -1) struct = -1;
      }
      state[i] = { struct, sh: sh && !sh.used ? sh.price : null, sl: sl && !sl.used ? sl.price : null, shAll: sh, slAll: sl };
    }
    return { state, sig };
  }

  function compute(bars, p) {
    const closes = bars.map((b) => b.close);
    const fast = TA.ema(closes, p.fast), slow = TA.ema(closes, p.slow), trend = TA.ema(closes, p.trend);
    const rsi = TA.rsi(closes, p.rsiLen), macd = TA.macd(closes), atr = TA.atr(bars, 14);
    const lastClosed = bars.length - 1 - (bars[bars.length - 1].closed ? 0 : 1);

    // ---- liquidity sweep engine (market-structure based, no look-ahead) ----
    const sw = sweepEngine(bars, atr, lastClosed, p);
    const conds = (i, side) => {
      if (p.strategy === 'sweep') {
        const s = side === 'buy' ? 1 : -1, st = sw.state[i] || {};
        const hit = sw.sig[i] && sw.sig[i].side === side;
        const lv = hit ? sw.sig[i].level : s > 0 ? st.sl : st.sh;
        const list = [
          { label: s > 0 ? 'โครงสร้างขาขึ้น (ทำ HH / เบรกขึ้นล่าสุด)' : 'โครงสร้างขาลง (ทำ LL / เบรกลงล่าสุด)', ok: st.struct === s },
          { label: (s > 0 ? 'มี Swing Low ให้กวาด (SSL) ' : 'มี Swing High ให้กวาด (BSL) ') + (lv ? fmtP(lv) : '—'), ok: !!lv },
          { label: s > 0 ? 'ไส้เทียนกวาดใต้ SSL แล้วปิดกลับเหนือ' : 'ไส้เทียนกวาดเหนือ BSL แล้วปิดกลับใต้', ok: !!hit },
        ];
        if (p.trendFilter) list.push({ label: `ราคา ${s > 0 ? 'เหนือ' : 'ใต้'} EMA ${p.trend}`, ok: trend[i] != null && s * (closes[i] - trend[i]) > 0 });
        return list;
      }
      const s = side === 'buy' ? 1 : -1;
      const list = [];
      const add = (label, ok) => list.push({ label, ok: !!ok });
      if (p.strategy === 'confluence' || p.strategy === 'ema') add(`EMA ${p.fast} ${s > 0 ? '>' : '<'} EMA ${p.slow}`, fast[i] != null && slow[i] != null && s * (fast[i] - slow[i]) > 0);
      if (p.strategy === 'confluence' || p.strategy === 'macd') add(`MACD ${s > 0 ? '>' : '<'} Signal`, macd.line[i] != null && macd.signal[i] != null && s * (macd.line[i] - macd.signal[i]) > 0);
      if (p.strategy === 'confluence') add(s > 0 ? `RSI 50–${p.ob}` : `RSI ${p.os}–50`, rsi[i] != null && (s > 0 ? rsi[i] > 50 && rsi[i] < p.ob : rsi[i] < 50 && rsi[i] > p.os));
      if (p.strategy === 'rsi') add(s > 0 ? `RSI ฟื้นจากต่ำกว่า ${p.os}` : `RSI หลุดจากเหนือ ${p.ob}`, rsi[i] != null && rsi[i - 1] != null && (s > 0 ? rsi[i - 1] < p.os && rsi[i] >= p.os : rsi[i - 1] > p.ob && rsi[i] <= p.ob));
      if (p.trendFilter) add(`ราคา ${s > 0 ? 'เหนือ' : 'ใต้'} EMA ${p.trend}`, trend[i] != null && s * (closes[i] - trend[i]) > 0);
      return list;
    };
    const trigger = (i, side) => {
      const U = side === 'buy';
      const ema = U ? crossUp(fast, slow, i) : crossDn(fast, slow, i);
      const mc = U ? crossUp(macd.line, macd.signal, i) : crossDn(macd.line, macd.signal, i);
      if (p.strategy === 'ema') return ema;
      if (p.strategy === 'macd') return mc;
      if (p.strategy === 'rsi') return true; // condition itself is the trigger
      if (p.strategy === 'sweep') return !!(sw.sig[i] && sw.sig[i].side === side);
      return ema || mc;
    };
    const fires = (i, side) => atr[i] != null && trigger(i, side) && conds(i, side).every((c) => c.ok);

    // signals + backtest
    const signals = [], trades = [];
    let pos = null, equity = 1, peak = 1, maxDD = 0;
    const closeTrade = (i, price, reason) => {
      const ret = (price / pos.entry - 1) * pos.dir - p.cost;
      equity *= 1 + ret; peak = Math.max(peak, equity); maxDD = Math.max(maxDD, 1 - equity / peak);
      Object.assign(pos.sig, { result: reason, ret, exitTime: bars[i].time });
      trades.push({ ret, reason }); pos = null;
    };
    for (let i = 2; i <= lastClosed; i++) {
      const b = bars[i];
      if (pos && i > pos.idx) {
        if (pos.dir > 0) { if (b.low <= pos.sl) closeTrade(i, pos.sl, 'SL'); else if (b.high >= pos.tp) closeTrade(i, pos.tp, 'TP'); }
        else { if (b.high >= pos.sl) closeTrade(i, pos.sl, 'SL'); else if (b.low <= pos.tp) closeTrade(i, pos.tp, 'TP'); }
      }
      const side = fires(i, 'buy') ? 'buy' : fires(i, 'sell') ? 'sell' : null;
      if (!side) continue;
      const dir = side === 'buy' ? 1 : -1, a = atr[i];
      let sl = b.close - dir * p.sl * a, tp = b.close + dir * p.tp * a;
      if (p.strategy === 'sweep') { sl = sw.sig[i].sl; tp = b.close + dir * p.rr * Math.abs(b.close - sl); }
      const sig = { idx: i, time: b.time, side, price: b.close, sl, tp, result: null, level: sw.sig[i] && sw.sig[i].level };
      signals.push(sig);
      if (pos && pos.dir !== dir) closeTrade(i, b.close, 'กลับฝั่ง');
      if (pos) { sig.result = 'ซ้ำ'; sig.dup = true; continue; }
      if (dir < 0 && !p.allowShort) { sig.result = 'ไม่เปิด Short'; continue; }
      pos = { dir, entry: b.close, sl: sig.sl, tp: sig.tp, idx: i, sig };
      sig.result = 'เปิดอยู่';
    }
    if (pos) { const last = bars[bars.length - 1].close; pos.sig.ret = (last / pos.entry - 1) * pos.dir - p.cost; }

    const wins = trades.filter((t) => t.ret > 0);
    const gp = wins.reduce((s, t) => s + t.ret, 0), gl = -trades.filter((t) => t.ret <= 0).reduce((s, t) => s + t.ret, 0);
    const startIdx = Math.max(p.trend, p.slow, 35);
    const stats = {
      trades: trades.length, win: trades.length ? wins.length / trades.length : null,
      ret: equity - 1, pf: gl > 0 ? gp / gl : gp > 0 ? Infinity : null, dd: maxDD,
      hold: bars[lastClosed].close / bars[Math.min(startIdx, lastClosed)].close - 1,
    };
    return { fast, slow, trend, rsi, macd, atr, signals, stats, open: pos, lastClosed, conds, closes, sw };
  }

  // ---------- render ----------
  const fmtP = (v) => {
    if (v == null || isNaN(v)) return '—';
    const d = inst().digits;
    return v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
  };
  const pips = (dist) => inst().metal ? '$' + Math.abs(dist).toFixed(2) : (Math.abs(dist) / inst().pip).toFixed(1) + ' pips';
  // spot gold trades Sun 22:00 – Fri 22:00 UTC; PAXG trades 24/7, so drop weekend bars
  const isWeekend = (t, dur) => {
    const d = new Date(t * 1000), wd = d.getUTCDay(), h = d.getUTCHours();
    if (dur >= 86400) return wd === 0 || wd === 6;
    return wd === 6 || (wd === 5 && h >= 22) || (wd === 0 && h < 22);
  };
  const fmtN = (v) => { const x = Math.abs(v); return v.toFixed(x >= 100 ? 1 : x >= 1 ? 2 : 5); };
  const pct = (v, sign = true) => (v == null ? '—' : (sign && v > 0 ? '+' : '') + (v * 100).toFixed(2) + '%');
  const fmtT = (t) => new Date(t * 1000).toLocaleString('th-TH', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
  const lt = (t) => t + TZ;
  const line = (arr) => state.bars.map((b, i) => (arr[i] == null ? { time: lt(b.time) } : { time: lt(b.time), value: arr[i] }));

  function renderAll(fit) {
    const p = params(), bars = state.bars;
    if (bars.length < 50) return;
    const r = compute(bars, p); state.calc = r;
    const I = inst();
    sCandle.applyOptions({ priceFormat: { type: 'price', precision: I.digits, minMove: Math.pow(10, -I.digits) } });
    sCandle.setData(bars.map((b) => ({ time: lt(b.time), open: b.open, high: b.high, low: b.low, close: b.close })));
    const sweepMode = p.strategy === 'sweep';
    sFast.setData(sweepMode ? [] : line(r.fast)); sSlow.setData(sweepMode ? [] : line(r.slow));
    sTrend.setData(p.trendFilter ? line(r.trend) : []);
    sRsi.setData(line(r.rsi));
    rsiOb.applyOptions({ price: p.ob }); rsiOs.applyOptions({ price: p.os });
    sMacd.setData(line(r.macd.line)); sSig.setData(line(r.macd.signal));
    sHist.setData(bars.map((b, i) => r.macd.hist[i] == null ? { time: lt(b.time) } : { time: lt(b.time), value: r.macd.hist[i], color: r.macd.hist[i] >= 0 ? 'rgba(38,179,134,.55)' : 'rgba(229,83,75,.55)' }));
    sCandle.setMarkers(r.signals.map((s) => ({
      time: lt(s.time), position: s.side === 'buy' ? 'belowBar' : 'aboveBar', shape: s.side === 'buy' ? 'arrowUp' : 'arrowDown',
      color: s.side === 'buy' ? up : dn, text: s.side === 'buy' ? 'BUY' : 'SELL', size: 1,
    })));
    state.priceLines.forEach((l) => sCandle.removePriceLine(l)); state.priceLines = [];
    const stNow = r.sw.state[r.lastClosed] || {};
    if (p.strategy === 'sweep') {
      if (stNow.sh) state.priceLines.push(sCandle.createPriceLine({ price: stNow.sh, color: 'rgba(232,179,74,.8)', lineStyle: 3, lineWidth: 1, title: 'BSL' }));
      if (stNow.sl) state.priceLines.push(sCandle.createPriceLine({ price: stNow.sl, color: 'rgba(232,179,74,.8)', lineStyle: 3, lineWidth: 1, title: 'SSL' }));
    }
    if (r.open) {
      state.priceLines.push(sCandle.createPriceLine({ price: r.open.sl, color: dn, lineStyle: 2, lineWidth: 1, title: 'SL' }));
      state.priceLines.push(sCandle.createPriceLine({ price: r.open.tp, color: up, lineStyle: 2, lineWidth: 1, title: 'TP' }));
      state.priceLines.push(sCandle.createPriceLine({ price: r.open.entry, color: '#8b95a5', lineStyle: 1, lineWidth: 1, title: 'Entry' }));
    }
    if (fit) { const n = bars.length; chP.timeScale().setVisibleLogicalRange({ from: n - 160, to: n + 6 }); }

    $('legend').innerHTML = (sweepMode ? `<span><i style="background:rgba(232,179,74,.8)"></i>BSL / SSL = สภาพคล่องที่รอถูกกวาด</span>` : `<span><i style="background:#e8b34a"></i>EMA ${p.fast}</span><span><i style="background:#6ea8fe"></i>EMA ${p.slow}</span>`) + (p.trendFilter ? `<span><i style="background:rgba(200,200,220,.6)"></i>EMA ${p.trend}</span>` : '');
    const li = r.lastClosed;
    $('rsiLbl').textContent = r.rsi[li] != null ? r.rsi[li].toFixed(1) : '';
    $('macdLbl').textContent = r.macd.line[li] != null ? `${fmtN(r.macd.line[li])} / ${fmtN(r.macd.signal[li])}` : '';
    $('stratHint').textContent = HINTS[p.strategy];
    document.querySelector('.settings').classList.toggle('mode-sweep', p.strategy === 'sweep');
    renderSignal(r, p); renderStats(r); renderLog(r); renderQuote();

    // new-signal detection
    const last = r.signals[r.signals.length - 1];
    if (last && state.lastSignalTime != null && last.time > state.lastSignalTime) alertSignal(last);
    state.lastSignalTime = last ? last.time : 0;
  }

  function renderSignal(r, p) {
    const last = [...r.signals].reverse().find((s) => !s.dup) || r.signals[r.signals.length - 1];
    const i = r.lastClosed;
    const bias = r.conds(i, 'buy'), biasS = r.conds(i, 'sell');
    const nb = bias.filter((c) => c.ok).length, ns = biasS.filter((c) => c.ok).length;
    const leanSide = nb >= ns ? 'buy' : 'sell', lean = leanSide === 'buy' ? bias : biasS;
    let head;
    if (!last) head = `<div class="sig-main"><span class="sig-badge wait">WAIT</span><div class="sig-meta">ยังไม่มีสัญญาณในช่วงข้อมูลนี้</div></div>`;
    else {
      const ago = i - last.idx;
      const rr = Math.abs(last.tp - last.price) / Math.abs(last.price - last.sl);
      head = `<div class="sig-main"><span class="sig-badge ${last.side}">${last.side.toUpperCase()}</span>
        <div class="sig-meta">${fmtT(last.time)} · ${ago === 0 ? 'แท่งล่าสุด' : ago + ' แท่งที่แล้ว'}<br>สถานะ: <b style="color:var(--text)">${last.result || '—'}</b>${last.ret != null ? ` <span class="${last.ret >= 0 ? 'up' : 'down'} mono">${pct(last.ret)}</span>` : ''}</div></div>
        <div class="levels"><div class="lv"><span>เข้า</span><b>${fmtP(last.price)}</b></div>
        <div class="lv"><span>Stop Loss</span><b class="down">${fmtP(last.sl)}</b><em>${pips(last.price - last.sl)}</em></div>
        <div class="lv"><span>Take Profit</span><b class="up">${fmtP(last.tp)}</b><em>${pips(last.tp - last.price)}</em></div></div>
        <div class="sig-meta" style="margin-top:6px">${last.level ? `กวาด${last.side === 'buy' ? ' SSL' : ' BSL'} ที่ ${fmtP(last.level)} · ` : ''}Risk:Reward 1:${rr.toFixed(1)} · ATR ${pips(r.atr[last.idx])}</div>`;
    }
    const checks = `<div class="sig-meta" style="margin-top:12px">เงื่อนไขแท่งที่ปิดล่าสุด (ฝั่ง ${leanSide === 'buy' ? 'ซื้อ' : 'ขาย'})</div>
      <ul class="reasons">${lean.map((c) => `<li class="${c.ok ? 'ok' : 'no'}">${c.label}</li>`).join('')}</ul>`;
    $('sigBody').innerHTML = head + checks;
  }

  function renderStats(r) {
    const s = r.stats;
    const cell = (k, v, cls = '') => `<div class="stat"><span>${k}</span><b class="${cls}">${v}</b></div>`;
    $('stats').innerHTML =
      cell('จำนวนเทรด', s.trades) +
      cell('Win rate', s.win == null ? '—' : (s.win * 100).toFixed(0) + '%') +
      cell('ผลตอบแทน', pct(s.ret), s.ret >= 0 ? 'up' : 'down') +
      cell('Profit factor', s.pf == null ? '—' : s.pf === Infinity ? '∞' : s.pf.toFixed(2)) +
      cell('Max DD', pct(-s.dd, false), 'down') +
      cell('ถือเฉยๆ', pct(s.hold), s.hold >= 0 ? 'up' : 'down');
    const b = state.bars;
    $('btRange').textContent = `${b.length} แท่ง · ต้นทุน ${num('costPct')}%/รอบ`;
  }

  function renderLog(r) {
    const rows = r.signals.slice().reverse();
    $('sigCount').textContent = rows.length + ' รายการ';
    if (!rows.length) { $('logBody').innerHTML = `<tr><td colspan="4" class="empty">ยังไม่มีสัญญาณ ลองเปลี่ยนกลยุทธ์หรือไทม์เฟรม</td></tr>`; return; }
    $('logBody').innerHTML = rows.map((s) => {
      const res = s.ret != null ? `<span class="${s.ret >= 0 ? 'up' : 'down'}">${pct(s.ret)}</span>` : `<span class="muted">${s.result || ''}</span>`;
      return `<tr data-i="${s.idx}" title="${s.result || ''}"><td>${fmtT(s.time)}</td><td><span class="pill ${s.side}">${s.side === 'buy' ? 'BUY' : 'SELL'}</span></td><td class="r">${fmtP(s.price)}</td><td class="r">${res}</td></tr>`;
    }).join('');
  }

  function renderQuote() {
    const b = state.bars; if (!b.length) return;
    const last = b[b.length - 1];
    // 24h change approximated from bars
    const span = { '15m': 96, '1h': 24, '4h': 6, '1d': 1 }[state.interval];
    const ref = b[Math.max(0, b.length - 1 - span)].close;
    const ch = last.close / ref - 1;
    $('qSym').textContent = inst().name;
    $('qSrc').textContent = inst().note || 'Yahoo Finance · 15 วินาที';
    $('qPrice').textContent = fmtP(last.close);
    $('qChg').textContent = pct(ch) + (state.interval === '1d' ? ' 1D' : ' 24H');
    $('qChg').className = 'q-chg mono ' + (ch >= 0 ? 'up' : 'down');
    document.title = `${fmtP(last.close)} ${inst().name.replace(/ /g, '')} — SignalDesk`;
  }

  // ---------- alerts ----------
  let audioCtx;
  function beep(side) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.frequency.value = side === 'buy' ? 880 : 440; o.connect(g); g.connect(audioCtx.destination);
      g.gain.setValueAtTime(0.12, audioCtx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
      o.start(); o.stop(audioCtx.currentTime + 0.5);
    } catch (e) {}
  }
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 4000);
  }
  function alertSignal(s) {
    const msg = `${s.level ? 'Sweep ' : ''}${s.side === 'buy' ? 'BUY' : 'SELL'} ${inst().name.replace(/ /g, '')} @ ${fmtP(s.price)} · SL ${fmtP(s.sl)} · TP ${fmtP(s.tp)}`;
    toast('สัญญาณใหม่: ' + msg);
    if (!state.notify) return;
    beep(s.side);
    try { if ('Notification' in window && Notification.permission === 'granted') new Notification('SignalDesk', { body: msg }); } catch (e) {}
  }
  $('notifyBtn').addEventListener('click', async () => {
    state.notify = !state.notify;
    if (state.notify) {
      beep('buy');
      try { if ('Notification' in window && Notification.permission === 'default') await Notification.requestPermission(); } catch (e) {}
    }
    $('notifyBtn').textContent = 'แจ้งเตือน: ' + (state.notify ? 'เปิด' : 'ปิด');
    $('notifyBtn').classList.toggle('on', state.notify);
    toast(state.notify ? 'จะแจ้งเตือนเมื่อแท่งเทียนปิดแล้วเกิดสัญญาณใหม่' : 'ปิดการแจ้งเตือนแล้ว');
  });

  // ---------- data ----------
  const setLive = (cls, txt) => { $('live').className = 'live ' + cls; $('liveText').textContent = txt; };
  const parseK = (k) => ({ time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4], closed: k[6] < Date.now() });

  let loadId = 0;
  function stopFeeds() {
    if (state.ws) { state.ws.onclose = null; state.ws.close(); state.ws = null; }
    if (state.poll) { clearInterval(state.poll); state.poll = null; }
  }
  const markClosed = (b) => { b.closed = b.time + DUR[state.interval] <= Date.now() / 1000; return b; };
  async function fetchYahoo(recent) {
    const res = await fetch(`${API}/api/candles?symbol=${state.symbol}&interval=${state.interval}${recent ? '&recent=1' : ''}`);
    if (!res.ok) throw new Error(res.status);
    const d = await res.json();
    return d.bars.map(markClosed);
  }
  async function load() {
    const id = ++loadId;
    document.dispatchEvent(new Event('sd:change'));
    stopFeeds();
    $('sigBody').innerHTML = '<div class="skeleton"></div>';
    setLive('', 'กำลังโหลดข้อมูล…');
    const I = inst();
    try {
      let bars;
      if (I.src === 'binance') {
        const res = await fetch(`${REST}?symbol=${I.bsym}&interval=${state.interval}&limit=1000`);
        if (!res.ok) throw new Error(res.status);
        bars = (await res.json()).map(parseK).filter((b) => !isWeekend(b.time, DUR[state.interval]));
      } else bars = await fetchYahoo(false);
      if (id !== loadId) return;
      if (bars.length < 50) throw new Error('not enough data');
      state.bars = bars;
      state.lastSignalTime = null;
      renderAll(true);
      if (I.src === 'binance') connectWs(id, I.bsym); else startPoll(id);
    } catch (e) {
      if (id !== loadId) return;
      setLive('err', 'โหลดข้อมูลไม่สำเร็จ');
      $('sigBody').innerHTML = `<div class="empty">ดึงข้อมูลราคาไม่ได้ ${I.src === 'yahoo' ? '(เซิร์ฟเวอร์ข้อมูลค่าเงินอาจปิดอยู่)' : ''} <button class="btn-ghost" id="retry">ลองใหม่</button></div>`;
      $('retry').onclick = load;
    }
  }

  // merge an incoming bar; returns true when a bar closed (needs full recompute)
  function mergeBar(bar) {
    const b = state.bars, last = b[b.length - 1];
    if (last && last.time === bar.time) { const wasClosed = last.closed; b[b.length - 1] = bar; return bar.closed && !wasClosed; }
    if (!last || bar.time > last.time) { const closedPrev = last && !last.closed; if (last) last.closed = true; b.push(bar); if (b.length > 1600) b.shift(); return closedPrev || bar.closed; }
    const i = b.findIndex((x) => x.time === bar.time); if (i >= 0) b[i] = bar;
    return false;
  }
  let tickPending = false;
  function tick(bar) {
    sCandle.update({ time: lt(bar.time), open: bar.open, high: bar.high, low: bar.low, close: bar.close });
    if (!tickPending) { tickPending = true; requestAnimationFrame(() => { tickPending = false; renderQuote(); }); }
  }
  function startPoll(id) {
    setLive('ok', 'อัปเดตทุก 15 วินาที');
    state.poll = setInterval(async () => {
      if (id !== loadId) return;
      try {
        const bars = await fetchYahoo(true);
        if (id !== loadId) return;
        let changed = false;
        bars.forEach((bar) => { if (mergeBar(bar)) changed = true; });
        if (changed) renderAll(false); else if (bars.length) tick(state.bars[state.bars.length - 1]);
        setLive('ok', 'อัปเดตทุก 15 วินาที');
      } catch (e) { setLive('err', 'อัปเดตล้มเหลว กำลังลองใหม่…'); }
    }, 15000);
  }
  function connectWs(id, bsym) {
    const ws = new WebSocket(`${WS}${bsym.toLowerCase()}@kline_${state.interval}`);
    state.ws = ws;
    ws.onopen = () => setLive('ok', 'เรียลไทม์');
    ws.onmessage = (ev) => {
      if (id !== loadId) return;
      const k = JSON.parse(ev.data).k; if (!k) return;
      const bar = { time: Math.floor(k.t / 1000), open: +k.o, high: +k.h, low: +k.l, close: +k.c, closed: k.x };
      if (isWeekend(bar.time, DUR[state.interval])) return;
      if (mergeBar(bar)) renderAll(false); else tick(bar);
    };
    ws.onerror = () => setLive('err', 'การเชื่อมต่อขัดข้อง');
    ws.onclose = () => { if (id !== loadId) return; setLive('err', 'หลุดการเชื่อมต่อ กำลังต่อใหม่…'); setTimeout(() => id === loadId && connectWs(id, bsym), 3000); };
  }

  // ---------- events ----------
  loadSettings();
  state.symbol = $('symbol').value;
  document.querySelectorAll('#interval button').forEach((btn) => {
    btn.classList.toggle('on', btn.dataset.v === state.interval);
    btn.addEventListener('click', () => {
      if (btn.dataset.v === state.interval) return;
      document.querySelectorAll('#interval button').forEach((b) => b.classList.toggle('on', b === btn));
      state.interval = btn.dataset.v; saveSettings(); load();
    });
  });
  $('symbol').addEventListener('change', () => { state.symbol = $('symbol').value; saveSettings(); load(); });
  ['strategy', 'emaFast', 'emaSlow', 'emaTrend', 'rsiLen', 'rsiOb', 'rsiOs', 'slAtr', 'tpAtr', 'costPct', 'swingLen', 'confirmBars', 'rrRatio', 'slBuf', 'allowShort', 'trendFilter'].forEach((k) =>
    $(k).addEventListener('change', () => { saveSettings(); state.lastSignalTime = null; renderAll(false); document.dispatchEvent(new Event('sd:params')); }));
  $('logBody').addEventListener('click', (e) => {
    const tr = e.target.closest('tr[data-i]'); if (!tr) return;
    const i = +tr.dataset.i; chP.timeScale().setVisibleLogicalRange({ from: i - 60, to: i + 60 });
  });
  chP.subscribeCrosshairMove((pr) => {
    if (!state.calc || !pr.time) return;
    const i = state.bars.findIndex((b) => lt(b.time) === pr.time); if (i < 0) return;
    const r = state.calc;
    $('rsiLbl').textContent = r.rsi[i] != null ? r.rsi[i].toFixed(1) : '';
    $('macdLbl').textContent = r.macd.line[i] != null ? `${fmtN(r.macd.line[i])} / ${fmtN(r.macd.signal[i])}` : '';
  });
  window.SD = { API, names: () => Object.fromEntries(Object.entries(INSTR).map(([k, v]) => [k, v.name])), ctx: () => ({ symbol: state.symbol, interval: state.interval, p: params() }), toast };
  load();
})();
