// Technical indicators — arrays aligned with input; null where not yet defined.
const TA = {
  ema(values, p) {
    const out = new Array(values.length).fill(null);
    const k = 2 / (p + 1);
    let prev = null, sum = 0, count = 0;
    for (let i = 0; i < values.length; i++) {
      const v = values[i];
      if (v == null) continue;
      if (prev == null) {
        sum += v; count++;
        if (count === p) { prev = sum / p; out[i] = prev; }
      } else {
        prev = v * k + prev * (1 - k); out[i] = prev;
      }
    }
    return out;
  },
  rsi(closes, p) {
    const out = new Array(closes.length).fill(null);
    let g = 0, l = 0;
    for (let i = 1; i < closes.length; i++) {
      const d = closes[i] - closes[i - 1];
      const up = Math.max(d, 0), dn = Math.max(-d, 0);
      if (i <= p) {
        g += up; l += dn;
        if (i === p) { g /= p; l /= p; out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l); }
      } else {
        g = (g * (p - 1) + up) / p; l = (l * (p - 1) + dn) / p;
        out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
      }
    }
    return out;
  },
  macd(closes, f = 12, s = 26, sig = 9) {
    const ef = TA.ema(closes, f), es = TA.ema(closes, s);
    const line = closes.map((_, i) => (ef[i] != null && es[i] != null ? ef[i] - es[i] : null));
    const signal = TA.ema(line, sig);
    const hist = line.map((v, i) => (v != null && signal[i] != null ? v - signal[i] : null));
    return { line, signal, hist };
  },
  atr(bars, p = 14) {
    const out = new Array(bars.length).fill(null);
    let prev = null, sum = 0;
    for (let i = 1; i < bars.length; i++) {
      const b = bars[i], pc = bars[i - 1].close;
      const tr = Math.max(b.high - b.low, Math.abs(b.high - pc), Math.abs(b.low - pc));
      if (i <= p) { sum += tr; if (i === p) { prev = sum / p; out[i] = prev; } }
      else { prev = (prev * (p - 1) + tr) / p; out[i] = prev; }
    }
    return out;
  },
};
const crossUp = (a, b, i) => a[i] != null && b[i] != null && a[i - 1] != null && b[i - 1] != null && a[i - 1] <= b[i - 1] && a[i] > b[i];
const crossDn = (a, b, i) => a[i] != null && b[i] != null && a[i - 1] != null && b[i - 1] != null && a[i - 1] >= b[i - 1] && a[i] < b[i];
