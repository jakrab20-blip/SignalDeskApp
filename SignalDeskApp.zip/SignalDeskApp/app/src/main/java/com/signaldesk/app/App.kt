package com.signaldesk.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Alerts.init(this)
    }
}
