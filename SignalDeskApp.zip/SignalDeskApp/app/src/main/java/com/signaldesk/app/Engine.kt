package com.signaldesk.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

// พอร์ตตรง ๆ จาก alerts.py (atr, sweep_signals, format_signal)
object Engine {

    private class Lvl(val price: Double, val idx: Int, var used: Boolean = false)
    private class Pend(val side: String, val lvl: Lvl, var ext: Double, val start: Int)
    private class Fired(val side: String, val sl: Double, val level: Double)

    fun atr(bars: List<Bar>, p: Int = 14): Array<Double?> {
        val out = arrayOfNulls<Double>(bars.size)
        var prev = 0.0
        var s = 0.0
        for (i in 1 until bars.size) {
            val b = bars[i]
            val pc = bars[i - 1].close
            val tr = maxOf(b.high - b.low, abs(b.high - pc), abs(b.low - pc))
            if (i <= p) {
                s += tr
                if (i == p) {
                    prev = s / p
                    out[i] = prev
                }
            } else {
                prev = (prev * (p - 1) + tr) / p
                out[i] = prev
            }
        }
        return out
    }

    fun sweepSignals(bars: List<Bar>, p: Params): List<Signal> {
        val n = maxOf(2, p.swing)
        val k = maxOf(0, p.confirm)
        val a = atr(bars)
        var sh: Lvl? = null
        var sl: Lvl? = null
        var pend: Pend? = null
        var struct = 0
        val sigs = ArrayList<Signal>()

        fun isPh(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].high >= bars[j].high else bars[kk].high > bars[j].high
                    if (bad) return false
                }
            }
            return true
        }

        fun isPl(j: Int): Boolean {
            for (kk in (j - n)..(j + n)) {
                if (kk != j) {
                    val bad = if (kk < j) bars[kk].low <= bars[j].low else bars[kk].low < bars[j].low
                    if (bad) return false
                }
            }
            return true
        }

        for (i in bars.indices) {
            val b = bars[i]
            val j = i - n
            if (j >= n) {
                if (isPh(j)) sh = Lvl(bars[j].high, j)
                if (isPl(j)) sl = Lvl(bars[j].low, j)
            }
            val buf = (a[i] ?: 0.0) * p.slBuf

            val curSh = sh
            val curSl = sl
            if (pend == null && struct == 1 && curSl != null && !curSl.used && b.low < curSl.price) {
                pend = Pend("buy", curSl, b.low, i)
                curSl.used = true
            } else if (pend == null && struct == -1 && curSh != null && !curSh.used && b.high > curSh.price) {
                pend = Pend("sell", curSh, b.high, i)
                curSh.used = true
            }

            var fired: Fired? = null
            val pd = pend
            if (pd != null) {
                if (pd.side == "buy") {
                    pd.ext = minOf(pd.ext, b.low)
                    if (b.close > pd.lvl.price) {
                        fired = Fired("buy", pd.ext - buf, pd.lvl.price)
                        pend = null
                    } else if (i - pd.start >= k) {
                        struct = -1
                        pend = null
                    }
                } else {
                    pd.ext = maxOf(pd.ext, b.high)
                    if (b.close < pd.lvl.price) {
                        fired = Fired("sell", pd.ext + buf, pd.lvl.price)
                        pend = null
                    } else if (i - pd.start >= k) {
                        struct = 1
                        pend = null
                    }
                }
            }

            if (pend == null && fired == null) {
                if (curSh != null && b.close > curSh.price && struct != 1) {
                    struct = 1
                } else if (curSl != null && b.close < curSl.price && struct != -1) {
                    struct = -1
                }
            }

            val ai = a[i]
            val f = fired
            if (f != null && ai != null && i >= 2) {
                val d = if (f.side == "buy") 1 else -1
                val entry = b.close
                sigs.add(
                    Signal(
                        f.side, f.sl, f.level, b.time, i, entry,
                        entry + d * p.rr * abs(entry - f.sl), ai
                    )
                )
            }
        }
        return sigs
    }

    private fun fmt(v: Double, digits: Int): String = String.format(Locale.US, "%,.${digits}f", v)

    private fun dist(symbol: String, d: Double): String {
        val info = Cfg.NAMES.getValue(symbol)
        return if (info.metal) String.format(Locale.US, "\$%.2f", abs(d))
        else String.format(Locale.US, "%.1f pips", abs(d) / info.pip)
    }

    // เหมือน Python {rr:g}: 2.0 -> "2", 1.5 -> "1.5"
    private fun fmtG(v: Double): String = v.toString().removeSuffix(".0")

    fun formatSignal(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        val side = if (s.side == "buy") "BUY" else "SELL"
        val lvl = if (s.side == "buy") "SSL" else "BSL"
        val dur = Cfg.DUR.getValue(w.interval)
        val sdf = SimpleDateFormat("dd/MM HH:mm", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        val t = sdf.format(Date((s.time + dur + 7 * 3600) * 1000))
        return "<b>$side ${info.name}</b> · ${w.interval.uppercase()}\n" +
            "Liquidity Sweep — กวาด $lvl ที่ ${fmt(s.level, info.digits)} แล้วปิดกลับ\n\n" +
            "เข้า: <code>${fmt(s.price, info.digits)}</code>\n" +
            "SL: <code>${fmt(s.sl, info.digits)}</code> (${dist(w.symbol, s.price - s.sl)})\n" +
            "TP: <code>${fmt(s.tp, info.digits)}</code> (${dist(w.symbol, s.tp - s.price)})\n" +
            "R:R 1:${fmtG(w.params.rr)}\n\n" +
            "แท่งปิด $t (เวลาไทย)\n" +
            "<i>SignalDesk · ไม่ใช่คำแนะนำการลงทุน</i>"
    }

    fun notificationTitle(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        return "${if (s.side == "buy") "BUY" else "SELL"} ${info.name} · ${w.interval.uppercase()}"
    }

    fun notificationText(w: Watch, s: Signal): String {
        val info = Cfg.NAMES.getValue(w.symbol)
        return "เข้า ${fmt(s.price, info.digits)} · SL ${fmt(s.sl, info.digits)} · TP ${fmt(s.tp, info.digits)}"
    }
}
