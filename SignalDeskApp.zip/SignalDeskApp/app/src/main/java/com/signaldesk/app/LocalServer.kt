package com.signaldesk.app

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private object BadGateway : Response.IStatus {
    override fun getDescription() = "502 Bad Gateway"
    override fun getRequestStatus() = 502
}

// เซิร์ฟเวอร์เล็กในแอป (127.0.0.1) ให้หน้าเว็บเดิมเรียก /api/... ได้เหมือนที่เคยเรียก server.py
class LocalServer(private val ctx: Context, port: Int) : NanoHTTPD("127.0.0.1", port) {

    private fun json(o: Any): Response =
        newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", o.toString())

    private fun err(status: Response.IStatus, msg: String): Response =
        newFixedLengthResponse(status, "application/json; charset=utf-8", JSONObject().put("detail", msg).toString())

    override fun serve(session: IHTTPSession): Response {
        return try {
            val uri = session.uri
            if (uri.startsWith("/api/")) api(session, uri) else asset(uri)
        } catch (e: Exception) {
            err(Response.Status.INTERNAL_ERROR, e.message ?: "error")
        }
    }

    private fun body(session: IHTTPSession): JSONObject {
        val files = HashMap<String, String>()
        session.parseBody(files)
        val raw = files["postData"] ?: ""
        return if (raw.isBlank()) JSONObject() else JSONObject(raw)
    }

    private fun api(session: IHTTPSession, uri: String): Response {
        val post = session.method == Method.POST
        return when {
            uri == "/api/health" -> json(JSONObject().put("ok", true))
            uri == "/api/candles" -> candles(session)
            uri == "/api/tg/status" -> json(Alerts.status())
            post && uri == "/api/tg/token" -> tg { 
                val b = body(session)
                json(JSONObject().put("ok", true).put("bot", Alerts.setToken(b.optString("token", ""))))
            }
            post && uri == "/api/tg/link" -> tg {
                val who = Alerts.linkChat()
                    ?: return@tg err(Response.Status.NOT_FOUND, "ยังไม่พบข้อความถึงบอท ให้เปิดแชตกับบอทแล้วกด Start หรือพิมพ์ /start ก่อน")
                Alerts.send("เชื่อมต่อ SignalDesk สำเร็จ จะส่งสัญญาณ Liquidity Sweep มาที่แชตนี้")
                json(JSONObject().put("ok", true).put("chat", who))
            }
            post && uri == "/api/tg/test" -> tg {
                Alerts.send("<b>ทดสอบ</b> ข้อความจาก SignalDesk ส่งถึงแล้ว")
                json(JSONObject().put("ok", true))
            }
            post && uri == "/api/tg/watch" -> tg {
                val b = body(session)
                val ws = Alerts.setWatch(
                    b.optString("symbol", "").uppercase(),
                    b.optString("interval", ""),
                    b.optJSONObject("params"),
                    b.optBoolean("on", true)
                )
                val arr = JSONArray()
                ws.forEach { arr.put(it.toJson()) }
                json(JSONObject().put("ok", true).put("watches", arr))
            }
            post && uri == "/api/tg/disconnect" -> {
                Alerts.disconnect()
                json(JSONObject().put("ok", true))
            }
            else -> err(Response.Status.NOT_FOUND, "Not Found")
        }
    }

    private fun tg(block: () -> Response): Response = try {
        block()
    } catch (e: IllegalArgumentException) {
        err(Response.Status.BAD_REQUEST, e.message ?: "")
    } catch (e: IllegalStateException) {
        err(Response.Status.BAD_REQUEST, e.message ?: "")
    } catch (e: TgException) {
        err(Response.Status.BAD_REQUEST, e.message ?: "")
    } catch (e: Exception) {
        err(BadGateway, "ติดต่อ Telegram ไม่ได้: ${e.message}")
    }

    private fun candles(session: IHTTPSession): Response {
        val p = session.parms
        val symbol = p["symbol"] ?: return err(Response.Status.BAD_REQUEST, "missing symbol")
        val interval = p["interval"] ?: "1h"
        val recent = (p["recent"] ?: "0") != "0"
        return try {
            val c = Market.buildCandles(symbol, interval, recent)
            val bars = JSONArray()
            for (b in c.bars) {
                bars.put(JSONObject().put("time", b.time).put("open", b.open).put("high", b.high).put("low", b.low).put("close", b.close))
            }
            json(
                JSONObject().put("symbol", c.symbol).put("interval", c.interval).put("bars", bars)
                    .put("price", c.price ?: JSONObject.NULL).put("marketTime", c.marketTime ?: JSONObject.NULL)
            )
        } catch (e: IllegalArgumentException) {
            err(Response.Status.BAD_REQUEST, e.message ?: "")
        } catch (e: Exception) {
            err(BadGateway, e.message ?: "upstream error")
        }
    }

    private fun mime(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html; charset=utf-8"
        "css" -> "text/css; charset=utf-8"
        "js" -> "application/javascript; charset=utf-8"
        "json" -> "application/json; charset=utf-8"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "ico" -> "image/x-icon"
        else -> "application/octet-stream"
    }

    private fun asset(uri: String): Response {
        var path = uri.trimStart('/')
        if (path.isEmpty()) path = "index.html"
        if (path.contains("..")) return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        return try {
            val resp = newChunkedResponse(Response.Status.OK, mime(path), ctx.assets.open("web/$path"))
            resp.addHeader("Cache-Control", "no-cache")
            resp
        } catch (e: IOException) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        }
    }
}

object ServerHost {
    private var inst: LocalServer? = null

    @Synchronized
    fun ensureStarted(ctx: Context) {
        val s = inst
        if (s != null && s.isAlive) return
        val n = LocalServer(ctx.applicationContext, Cfg.PORT)
        n.start(NanoHTTPD.SOCKET_READ_TIMEOUT, true)
        inst = n
    }
}
