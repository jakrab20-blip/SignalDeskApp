package com.signaldesk.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var batteryAsked = false

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.setBackgroundColor(0xFF0C0F14.toInt())
        web = WebView(this)
        web.setBackgroundColor(0xFF0C0F14.toInt())
        root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)

        try {
            ServerHost.ensureStarted(this)
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดเซิร์ฟเวอร์ในแอปไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
        }

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "127.0.0.1") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                    // ไม่มีแอปเปิดลิงก์นี้
                }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("ตกลง") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("ตกลง") { _, _ -> result.confirm() }
                    .setNegativeButton("ยกเลิก") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        web.loadUrl("http://127.0.0.1:${Cfg.PORT}/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // ถ้ามีรายการเฝ้าอยู่แล้ว ให้ปลุกบริการเบื้องหลังกลับมา
        MonitorService.sync(this)
    }

    override fun onResume() {
        super.onResume()
        Alerts.listener = { maybeAskBattery() }
        maybeAskBattery()
    }

    override fun onPause() {
        Alerts.listener = null
        super.onPause()
    }

    private fun maybeAskBattery() {
        if (batteryAsked || Alerts.watchCount() == 0) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        batteryAsked = true
        AlertDialog.Builder(this)
            .setTitle("ให้แอปทำงานเบื้องหลังได้ต่อเนื่อง")
            .setMessage(
                "เพื่อให้ส่งสัญญาณได้แม้ปิดจอ กรุณากด \"ตั้งค่า\" แล้วเลือก \"อนุญาต\" (ปิดการประหยัดแบตสำหรับ SignalDesk)\n\n" +
                    "มือถือบางยี่ห้อ (Xiaomi, OPPO, Vivo, Samsung) ควรตั้งแอปนี้เป็น \"ไม่จำกัด\" หรือเปิด \"เริ่มอัตโนมัติ\" ในตั้งค่าแอปด้วย"
            )
            .setPositiveButton("ตั้งค่า") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
            .setNegativeButton("ไว้ทีหลัง", null)
            .show()
    }
}
