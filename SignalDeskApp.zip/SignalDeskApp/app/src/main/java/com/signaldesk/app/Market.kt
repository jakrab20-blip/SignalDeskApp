package com.signaldesk.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

data class Candles(
    val symbol: String,
    val interval: String,
    val bars: List<Bar>,
    val price: Double?,
    val marketTime: Long?
)

// พอร์ตจาก server.py (fetch_yahoo / to_4h / build_candles) และ alerts.py (fetch_bars)
object Market {
    private data class Yahoo(val gmtoffset: Long, val bars: List<Bar>, val price: Double?, val marketTime: Long?)

    private val cache = ConcurrentHashMap<String, Pair<Long, Yahoo>>()

    private fun optNum(o: JSONObject?, key: String): Double? =
        if (o != null && o.has(key) && !o.isNull(key)) o.getDouble(key) else null

    private fun fetchYahoo(ticker: String, yint: String, rng: String): Yahoo {
        val key = "$ticker|$yint|$rng"
        cache[key]?.let { if (System.currentTimeMillis() - it.first < 10_000) return it.second }

        var res: JSONObject? = null
        var lastErr: Exception? = null
        for (host in listOf("query1", "query2")) {
            try {
                val url = "https://$host.finance.yahoo.com/v8/finance/chart/$ticker?interval=$yint&range=$rng"
                val data = JSONObject(Http.get(url, 12000))
                res = data.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
                break
            } catch (e: Exception) {
                lastErr = e
            }
        }
        if (res == null) throw UpstreamException("upstream error: $lastErr")

        val ts: JSONArray? = res.optJSONArray("timestamp")
        val q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val o = q.getJSONArray("open")
        val h = q.getJSONArray("high")
        val l = q.getJSONArray("low")
        val c = q.getJSONArray("close")

        val bars = ArrayList<Bar>()
        if (ts != null) {
            for (i in 0 until ts.length()) {
                if (i >= o.length() || i >= h.length() || i >= l.length() || i >= c.length()) break
                if (o.isNull(i) || h.isNull(i) || l.isNull(i) || c.isNull(i)) continue
                val t = ts.getLong(i)
                val bar = Bar(t, o.getDouble(i), h.getDouble(i), l.getDouble(i), c.getDouble(i))
                if (bars.isNotEmpty() && bars.last().time == t) bars[bars.size - 1] = bar else bars.add(bar)
            }
        }

        val meta = res.optJSONObject("meta")
        // แท่งสดถูกประทับเวลาปัจจุบัน ให้ปัดลงเป็นต้นช่วงเวลา
        val step: Long? = when (yint) {
            "15m" -> 900L
            "60m" -> 3600L
            else -> null
        }
        if (step != null && bars.isNotEmpty()) {
            val last = bars.last()
            val nb = last.copy(time = last.time - last.time % step)
            bars[bars.size - 1] = nb
            if (bars.size > 1 && bars[bars.size - 2].time == nb.time) {
                val p = bars[bars.size - 2]
                bars[bars.size - 2] = Bar(p.time, p.open, max(p.high, nb.high), min(p.low, nb.low), nb.close)
                bars.removeAt(bars.size - 1)
            }
        }

        val out = Yahoo(
            meta?.optLong("gmtoffset", 0L) ?: 0L,
            bars,
            optNum(meta, "regularMarketPrice"),
            optNum(meta, "regularMarketTime")?.toLong()
        )
        cache[key] = Pair(System.currentTimeMillis(), out)
        return out
    }

    private fun to4h(bars: List<Bar>): List<Bar> {
        val out = ArrayList<Bar>()
        for (b in bars) {
            val bucket = b.time - b.time % 14400
            if (out.isNotEmpty() && out.last().time == bucket) {
                val o = out.last()
                out[out.size - 1] = o.copy(high = max(o.high, b.high), low = min(o.low, b.low), close = b.close)
            } else {
                out.add(Bar(bucket, b.open, b.high, b.low, b.close))
            }
        }
        return out
    }

    fun buildCandles(symbol: String, interval: String, recent: Boolean = false): Candles {
        val sym = symbol.uppercase()
        val ticker = Cfg.TICKERS[sym]
        val iv = Cfg.INTERVALS[interval]
        if (ticker == null || iv == null) throw IllegalArgumentException("unsupported symbol or interval")
        val (yint, full, short) = iv
        val d = fetchYahoo(ticker, yint, if (recent) short else full)

        var bars: List<Bar> = d.bars
        if (interval == "4h") bars = to4h(bars)
        if (interval == "1d") {
            // แท่งรายวัน Yahoo ประทับที่เปิดตลาด ปรับให้เป็น 00:00 UTC
            val norm = ArrayList<Bar>()
            for (b in bars) {
                val t = b.time + d.gmtoffset
                val r = Math.floorMod(t, 86400L)
                val nt = if (r < 7200 || r > 79200) t - r + (if (r > 79200) 86400L else 0L) else t - r
                val nb = b.copy(time = nt)
                if (norm.isNotEmpty() && norm.last().time == nt) norm[norm.size - 1] = nb else norm.add(nb)
            }
            bars = norm
        }
        return Candles(sym, interval, bars.takeLast(Cfg.LIMIT), d.price, d.marketTime)
    }

    private fun isWeekend(t: Long, dur: Long): Boolean {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.timeInMillis = t * 1000
        val wd = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = อาทิตย์
        val h = cal.get(Calendar.HOUR_OF_DAY)
        if (dur >= 86400L) return wd == 0 || wd == 6
        return wd == 6 || (wd == 5 && h >= 22) || (wd == 0 && h < 22)
    }

    /** เฉพาะแท่งที่ปิดแล้ว เรียงเก่าไปใหม่ */
    fun fetchBars(symbol: String, interval: String): List<Bar> {
        val dur = Cfg.DUR[interval] ?: throw IllegalArgumentException("unsupported symbol or interval")
        val nowSec = System.currentTimeMillis() / 1000
        if (symbol == "XAUUSD") {
            val url = "https://data-api.binance.vision/api/v3/klines?symbol=PAXGUSDT&interval=$interval&limit=1000"
            val raw = JSONArray(Http.get(url, 15000))
            val out = ArrayList<Bar>()
            for (i in 0 until raw.length()) {
                val k = raw.getJSONArray(i)
                val t = k.getLong(0) / 1000
                val closed = k.getLong(6) < nowSec * 1000
                if (!closed || isWeekend(t, dur)) continue
                out.add(Bar(t, k.getString(1).toDouble(), k.getString(2).toDouble(), k.getString(3).toDouble(), k.getString(4).toDouble()))
            }
            return out
        }
        return buildCandles(symbol, interval).bars.filter { it.time + dur <= nowSec }
    }
}
