package com.signaldesk.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Bar(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double)

data class Params(
    val swing: Int,
    val confirm: Int,
    val rr: Double,
    val slBuf: Double,
    val allowShort: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("swing", swing)
        .put("confirm", confirm)
        .put("rr", rr)
        .put("slBuf", slBuf)
        .put("allowShort", allowShort)

    companion object {
        val DEFAULT = Params(5, 1, 2.0, 0.1, true)

        // เหมือน alerts.py: เอาเฉพาะคีย์ที่รู้จัก ที่เหลือใช้ค่าเริ่มต้น
        fun fromJson(o: JSONObject?): Params {
            if (o == null) return DEFAULT
            return Params(
                o.optDouble("swing", DEFAULT.swing.toDouble()).toInt(),
                o.optDouble("confirm", DEFAULT.confirm.toDouble()).toInt(),
                o.optDouble("rr", DEFAULT.rr),
                o.optDouble("slBuf", DEFAULT.slBuf),
                o.optBoolean("allowShort", DEFAULT.allowShort)
            )
        }
    }
}

data class Watch(val symbol: String, val interval: String, val params: Params) {
    fun toJson(): JSONObject = JSONObject()
        .put("symbol", symbol)
        .put("interval", interval)
        .put("params", params.toJson())
}

data class Signal(
    val side: String,
    val sl: Double,
    val level: Double,
    val time: Long,
    val idx: Int,
    val price: Double,
    val tp: Double,
    val atr: Double
)

data class SymInfo(val name: String, val digits: Int, val pip: Double, val metal: Boolean)

class TgException(message: String) : Exception(message)
class UpstreamException(message: String) : Exception(message)

object Cfg {
    const val PORT = 8765
    const val CHECK_EVERY = 30
    const val LIMIT = 1500

    val DUR = mapOf("15m" to 900L, "1h" to 3600L, "4h" to 14400L, "1d" to 86400L)

    val NAMES = mapOf(
        "XAUUSD" to SymInfo("XAU/USD", 2, 0.1, true),
        "GC" to SymInfo("Gold Futures", 1, 0.1, true),
        "SI" to SymInfo("Silver Futures", 3, 0.01, true),
        "EURUSD" to SymInfo("EUR/USD", 5, 0.0001, false),
        "GBPUSD" to SymInfo("GBP/USD", 5, 0.0001, false),
        "USDJPY" to SymInfo("USD/JPY", 3, 0.01, false),
        "AUDUSD" to SymInfo("AUD/USD", 5, 0.0001, false),
        "USDCAD" to SymInfo("USD/CAD", 5, 0.0001, false),
        "USDCHF" to SymInfo("USD/CHF", 5, 0.0001, false),
        "NZDUSD" to SymInfo("NZD/USD", 5, 0.0001, false),
        "EURJPY" to SymInfo("EUR/JPY", 3, 0.01, false),
        "GBPJPY" to SymInfo("GBP/JPY", 3, 0.01, false),
        "EURGBP" to SymInfo("EUR/GBP", 5, 0.0001, false),
        "AUDJPY" to SymInfo("AUD/JPY", 3, 0.01, false),
        "USDTHB" to SymInfo("USD/THB", 3, 0.01, false)
    )

    val TICKERS = mapOf(
        "GC" to "GC=F", "SI" to "SI=F",
        "EURUSD" to "EURUSD=X", "GBPUSD" to "GBPUSD=X", "USDJPY" to "USDJPY=X", "AUDUSD" to "AUDUSD=X",
        "USDCAD" to "USDCAD=X", "USDCHF" to "USDCHF=X", "NZDUSD" to "NZDUSD=X", "EURJPY" to "EURJPY=X",
        "GBPJPY" to "GBPJPY=X", "EURGBP" to "EURGBP=X", "AUDJPY" to "AUDJPY=X", "USDTHB" to "THB=X"
    )

    // interval -> (yahoo interval, full range, recent range)
    val INTERVALS = mapOf(
        "15m" to Triple("15m", "60d", "2d"),
        "1h" to Triple("60m", "730d", "5d"),
        "4h" to Triple("60m", "730d", "10d"),
        "1d" to Triple("1d", "5y", "1mo")
    )
}

object Http {
    private const val UA = "Mozilla/5.0"

    fun get(url: String, timeoutMs: Int = 15000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", UA)
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code >= 400) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }

    // คืน (รหัส HTTP, เนื้อหา) ไม่โยนข้อผิดพลาดเมื่อ HTTP >= 400 เพราะ Telegram ส่งเหตุผลมาในเนื้อหา
    fun postForm(url: String, params: Map<String, String>, timeoutMs: Int = 15000): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            val body = params.entries.joinToString("&") {
                URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            c.disconnect()
        }
    }
}
