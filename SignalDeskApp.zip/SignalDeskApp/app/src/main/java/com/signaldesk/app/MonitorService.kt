package com.signaldesk.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

// Foreground Service: เช็กสัญญาณทุก 30 วินาที ต่อเนื่องแม้ปิดแอป
class MonitorService : Service() {

    @Volatile private var running = false
    private var thread: Thread? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.ensureChannels(this)
        ServiceCompat.startForeground(
            this,
            Notifier.ID_MONITOR,
            Notifier.monitor(this, Alerts.watchCount()),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        try {
            ServerHost.ensureStarted(this)
        } catch (e: Exception) {
            Alerts.recordError("เปิดเซิร์ฟเวอร์ในแอปไม่ได้: ${e.message}")
        }
        if (!running) {
            running = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SignalDesk::monitor").apply {
                setReferenceCounted(false)
                acquire()
            }
            thread = Thread { loop() }.apply {
                isDaemon = true
                name = "signal-loop"
                start()
            }
        }
        return START_STICKY
    }

    private fun loop() {
        while (running) {
            try {
                if (Alerts.watchCount() == 0) {
                    stopSelf()
                    return
                }
                Alerts.checkOnce()
            } catch (e: Throwable) {
                Alerts.recordError(e.message ?: e.toString())
            }
            var waited = 0
            while (running && waited < Cfg.CHECK_EVERY) {
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    return
                }
                waited++
            }
        }
    }

    override fun onDestroy() {
        running = false
        thread?.interrupt()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        /** เริ่มบริการถ้ามีรายการเฝ้า หยุดถ้าไม่มี */
        fun sync(c: Context) {
            val app = c.applicationContext
            val intent = Intent(app, MonitorService::class.java)
            try {
                if (Alerts.watchCount() > 0) ContextCompat.startForegroundService(app, intent)
                else app.stopService(intent)
            } catch (e: Exception) {
                Alerts.recordError("เริ่มบริการเบื้องหลังไม่ได้: ${e.message}")
            }
        }
    }
}
