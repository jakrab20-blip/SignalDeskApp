package com.signaldesk.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object Notifier {
    const val CH_MONITOR = "monitor"
    const val CH_SIGNAL = "signals"
    const val ID_MONITOR = 1

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "การเฝ้าสัญญาณเบื้องหลัง", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SIGNAL, "สัญญาณเทรด", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openApp(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun monitor(c: Context, count: Int): Notification =
        NotificationCompat.Builder(c, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("SignalDesk กำลังเฝ้าสัญญาณ")
            .setContentText("เฝ้า $count รายการ ตรวจทุก ${Cfg.CHECK_EVERY} วินาที")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(c))
            .build()

    fun signal(c: Context, title: String, text: String) {
        try {
            ensureChannels(c)
            val n = NotificationCompat.Builder(c, CH_SIGNAL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(c))
                .build()
            c.getSystemService(NotificationManager::class.java)
                .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        } catch (e: Exception) {
            // ไม่มีสิทธิ์แจ้งเตือนก็ข้ามไป ยังส่ง Telegram ได้
        }
    }
}
